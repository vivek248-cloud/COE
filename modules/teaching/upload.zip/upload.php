<?php
/**
 * Interactive Question Bank Entry & Draft Management
 * Holy Cross College (Autonomous) - Examination Management System
 * Dynamic Course Loading, Section Rule Automation (1M, 5M, 10M),
 * Real-Time Question Bank Blueprint Matrix, Diagram Attachments & HOD Review Flow
 */
define('PAGE_TITLE', 'Interactive Question Bank Entry');
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/system.php';
require_once __DIR__ . '/../../includes/question_rules.php';
require_once __DIR__ . '/../../includes/question_bank_blueprint.php';

requireAuth();
if (empty($_SESSION['qps_review_csrf'])) $_SESSION['qps_review_csrf'] = bin2hex(random_bytes(32));
if (isLoggedIn() && empty($_SESSION['qps_static_role']) && empty($_SESSION['qps_dean_authenticated'])) $_SESSION['qps_portal_role'] = 'STAFF';

$pdo = getDBConnection();
$user = getCurrentUser();
qps_ensure_aux_schema($pdo);
qps_ensure_question_draft_schema($pdo);

$isCoe = isCOE();
$isHod = isHOD();

// Fetch assigned courses
$assignedCourses = [];
try {
    if ($isCoe) {
        $st = $pdo->query("SELECT c.coursecode as papercode, c.coursetitle, c.dept_code, c.level, c.programme, c.maxmark, c.credit, c.type, c.papertype, c.coursetype1, c.coursetype, d.name as dept_name FROM courses c LEFT JOIN departments d ON d.code = c.dept_code ORDER BY c.coursecode ASC");
        $assignedCourses = $st->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $st = $pdo->prepare("SELECT DISTINCT tf.papercode,
                COALESCE(c.coursetitle, tf.papercode) as coursetitle,
                COALESCE(c.dept_code, tf.deptcode) as dept_code,
                c.level, c.programme, c.maxmark, c.credit, c.type, c.papertype, c.coursetype1, c.coursetype, d.name as dept_name
              FROM timetablefaculty tf
              LEFT JOIN courses c ON UPPER(c.coursecode) = UPPER(tf.papercode)
              LEFT JOIN departments d ON d.code = COALESCE(c.dept_code, tf.deptcode)
              WHERE UPPER(tf.fid) = UPPER(?) ORDER BY tf.papercode");
        $st->execute([$user['staff_code']]);
        $assignedCourses = $st->fetchAll(PDO::FETCH_ASSOC);

        if (empty($assignedCourses)) {
            $userDept = $user['dept_code'] ?? '';
            $stF = $pdo->prepare("SELECT c.coursecode as papercode, c.coursetitle, c.dept_code, c.level, c.programme, c.maxmark, c.credit, c.type, c.papertype, c.coursetype1, c.coursetype, d.name as dept_name FROM courses c LEFT JOIN departments d ON d.code = c.dept_code WHERE UPPER(c.dept_code) = UPPER(?) OR ? = '' ORDER BY c.coursecode ASC LIMIT 50");
            $stF->execute([$userDept, $userDept]);
            $assignedCourses = $stF->fetchAll(PDO::FETCH_ASSOC);
        }
    }
} catch (Throwable $e) {}

$defaultCourse = !empty($assignedCourses) ? $assignedCourses[0]['papercode'] : '';
$selectedCourseCode = strtoupper(trim((string)($_GET['paper_code'] ?? ($_GET['course'] ?? $defaultCourse))));
$departments = array_unique(array_map(fn($c) => $c['dept_code'], $assignedCourses));
$allowedRuleMarks = qps_allowed_total_marks($pdo);

require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/navbar.php';
?>

<style>

  .qbank-hero { position: relative; isolation: isolate; overflow: hidden; border-color: #e2e8f0; box-shadow: 0 12px 32px rgba(15, 23, 42, .06); }
  .qbank-hero::after { content: ''; position: absolute; z-index: -1; width: 18rem; height: 18rem; right: -7rem; top: -11rem; border-radius: 9999px; background: radial-gradient(circle, rgba(99,102,241,.12), transparent 68%); pointer-events: none; }
  .qbank-hero h1 { font-size: clamp(1.25rem, 2vw, 1.65rem); line-height: 1.2; }
  .qbank-hero .qbank-hero-actions { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: .625rem; }
  .qbank-hero .qbank-hero-actions a { min-height: 2.75rem; white-space: nowrap; }
  .qbank-overview { border-color: #e2e8f0; box-shadow: 0 12px 32px rgba(15, 23, 42, .05); }
  .qbank-course-grid { grid-template-columns: minmax(0, 1.25fr) minmax(0, 1fr) minmax(15rem, .9fr); }
  .qbank-course-grid > div { grid-column: auto / span 1 !important; }
  .course-select-wrap .qps-searchable-wrapper { display: block !important; width: 100% !important; }
  .course-select-wrap .qps-searchable-trigger { min-height: 3rem; padding-left: 2.75rem !important; padding-right: 2.75rem !important; border-color: #cbd5e1; background: #f8fafc; }
  .course-select-wrap .qps-searchable-trigger:hover { background: #fff; border-color: #a5b4fc; }
  .course-select-wrap .qps-searchable-trigger > span:first-child { min-width: 0; flex: 1 1 auto; line-height: 1.35; white-space: normal !important; overflow-wrap: anywhere; }
  #courseCodeBadge { flex: 0 0 auto; max-width: 8rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  #draftStatusBadge { min-height: 2.75rem; white-space: nowrap; }
  #btnSubmitHod { min-height: 2.75rem; white-space: nowrap; }
  .qbank-metrics { grid-template-columns: repeat(4, minmax(0, 1fr)); }
  .qbank-metrics > div { min-width: 0; min-height: 7rem; display: flex; flex-direction: column; justify-content: space-between; gap: .5rem; padding: 1rem; border-radius: 1rem; transition: transform .18s ease, box-shadow .18s ease; }
  .qbank-metrics > div:hover { transform: translateY(-2px); box-shadow: 0 10px 24px rgba(15, 23, 42, .07); }
  .qbank-metrics > div > span:first-child { display: block; min-height: 1.7rem; line-height: 1.3; overflow-wrap: anywhere; }
  .qbank-metrics > div > div { line-height: 1; }
  .qbank-metrics > div > span:last-child { line-height: 1.35; }
.qbank-tabs {
  position: sticky; top: 60px; z-index: 1000;
  display: flex; align-items: stretch; flex-wrap: wrap; gap: .5rem;
  padding: .35rem;
  border: 1px solid #e2e8f0;
  border-radius: 1rem;
  background: #020618;
}

/* The sliding liquid blob (created by the JS below) */
.qbank-glider {
  position: absolute; left: 0; top: 0; width: 0; height: 0;
  border-radius: .75rem;
  background: linear-gradient(160deg, #ffffff, #f1f5f9);
  box-shadow:
    inset 0 1px 1px rgba(255, 255, 255, .9),
    inset 0 -8px 14px rgba(148, 163, 184, .22),
    0 6px 18px rgba(255, 255, 255, .18);
  opacity: 0;
  pointer-events: none;
  z-index: 0;
  transition:
    left .5s cubic-bezier(.34, 1.45, .5, 1),
    top .5s cubic-bezier(.34, 1.45, .5, 1),
    width .5s cubic-bezier(.34, 1.45, .5, 1),
    height .5s cubic-bezier(.34, 1.45, .5, 1),
    opacity .2s ease;
}
.qbank-glider::before {               /* soft gloss on the top half */
  content: ""; position: absolute; inset: 0 0 50% 0; border-radius: inherit;
  background: linear-gradient(180deg, rgba(255, 255, 255, .9), rgba(255, 255, 255, 0));
}
.qbank-glider.no-anim { transition: none; }

.qbank-tabs > button {
  position: relative; z-index: 1;      /* sits above the blob */
  color: #fff !important;              /* default: white on the dark bar */
  background: transparent !important;
  border: 1px solid transparent !important;
  box-shadow: none !important;
  min-width: 0; min-height: 3rem; flex: 1 1 12rem;
  justify-content: center; text-align: center;
  white-space: normal; line-height: 1.25;
  border-radius: .75rem;
  padding: .65rem 1rem;
  transition: transform .3s cubic-bezier(.34, 1.56, .64, 1), color .25s ease;
}
.qbank-tabs > button > i { flex: 0 0 auto; }
.qbank-tabs > button.border-indigo-600 { font-weight: 600; }

/* Tab currently under the white blob: black text */
.qbank-tabs > button.qbank-under { color: #000 !important; }

.qbank-tabs > button:active { transform: scale(.96); }
.qbank-tabs > button:focus-visible { outline: 2px solid #fff; outline-offset: 2px; }

@media (prefers-reduced-motion: reduce) {
  .qbank-glider { transition: opacity .2s ease; }
}

@media (prefers-reduced-motion: reduce) {
  .qbank-glider { transition: opacity .2s ease; }
}
  .qbank-page :focus-visible { outline: 3px solid rgba(99,102,241,.35); outline-offset: 2px; }
  @media (max-width: 1279px) {
    .qbank-metrics { grid-template-columns: repeat(3, minmax(0, 1fr)); }
  }
  @media (max-width: 1023px) {
    .qbank-course-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .qbank-course-grid > :last-child { grid-column: 1 / -1 !important; justify-content: flex-start; }
  }
  @media (max-width: 639px) {
    .qbank-page { padding: 1rem; }
    .qbank-hero { padding: 1.125rem; }
    .qbank-hero .qbank-hero-actions { justify-content: stretch; }
    .qbank-hero .qbank-hero-actions a { flex: 1 1 100%; justify-content: center; }
    .qbank-course-grid { grid-template-columns: minmax(0, 1fr); }
    .qbank-course-grid > :last-child { grid-column: auto !important; justify-content: stretch; flex-wrap: wrap; }
    .qbank-metrics { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: .625rem; }
    .qbank-metrics > div { min-height: 6.75rem; padding: .75rem; }
    .qbank-metrics > div > span:first-child { font-size: 10px; }
    .qbank-tabs > button { flex-basis: 100%; justify-content: flex-start; text-align: left; }
  }
  @media (prefers-reduced-motion: reduce) {
    .qbank-metrics > div { transition: none; }
  }
</style>

<div class="qbank-page mx-auto w-full max-w-7xl space-y-6 p-4 sm:p-6 lg:p-8">
  
  <!-- Page Header -->
  <div class="qbank-hero flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm">
    <div class="flex items-center gap-4">
      <div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500 to-indigo-700 flex items-center justify-center text-white shadow-lg shadow-indigo-200">
        <i data-lucide="edit-3" class="w-7 h-7"></i>
      </div>
      <div>
        <div class="flex items-center gap-2">
          <h1 class="text-2xl font-bold text-slate-900 tracking-tight">Interactive Question Bank Entry</h1>
          <span class="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
            <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> Auto-Sync
          </span>
        </div>
        <p class="text-sm text-slate-500 mt-0.5">Structured question creation with real-time blueprint compilation and automated section mapping</p>
      </div>
    </div>
    
    <div class="qbank-hero-actions flex items-center gap-3">
      <a href="<?php echo getBaseUrl(); ?>/modules/teaching/question_bank_blueprint.php" class="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all">
        <i data-lucide="layout-grid" class="w-4 h-4 text-slate-600"></i> Blueprint Master
      </a>
      <a href="<?php echo getBaseUrl(); ?>/modules/teaching/corrections.php" class="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-xl transition-all">
        <i data-lucide="eye" class="w-4 h-4"></i> View All Banks
      </a>
    </div>
  </div>

  <!-- Course Selector & Live Status Header -->
  <div class="qbank-overview bg-white rounded-2xl border border-slate-200/80 shadow-sm p-6">
    <div class="qbank-course-grid grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
      <div class="md:col-span-5">
        <label for="courseSelect" class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Select Allocated Course</label>
        <div class="relative course-select-wrap">
          <select id="courseSelect" class="w-full pl-10 pr-10 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-semibold focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all appearance-none">
            <?php foreach ($assignedCourses as $c): ?>
              <option value="<?php echo htmlspecialchars($c['papercode'], ENT_QUOTES); ?>" data-course-maxmark="<?php echo htmlspecialchars((string)($c['maxmark'] ?? ''), ENT_QUOTES); ?>" data-course-level="<?php echo htmlspecialchars((string)($c['level'] ?? ''), ENT_QUOTES); ?>" data-course-programme="<?php echo htmlspecialchars((string)($c['programme'] ?? ''), ENT_QUOTES); ?>" <?php echo (strtoupper($c['papercode']) === $selectedCourseCode) ? 'selected' : ''; ?>>
                <?php echo htmlspecialchars($c['papercode'] . ' - ' . $c['coursetitle']); ?>
              </option>
            <?php endforeach; ?>
          </select>
          <i data-lucide="book-open" class="w-5 h-5 text-slate-400 absolute left-3.5 top-3.5 pointer-events-none"></i>
          <!-- <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400 absolute right-3.5 top-4 pointer-events-none"></i> -->
        </div>
      </div>

      <div class="md:col-span-4 flex items-center gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200/60">
        <div class="w-10 h-10 rounded-lg bg-indigo-100 flex items-center justify-center text-indigo-800 font-bold text-xs" id="courseCodeBadge">
          <?php echo htmlspecialchars($departments[0] ?? '---'); ?>
        </div>
        <div class="min-w-0 flex-1">
          <h4 class="text-xs font-bold text-slate-400 uppercase tracking-wider">Active Course</h4>
          <p class="text-sm font-semibold text-slate-800 truncate" id="courseTitleText">Loading Course Title...</p>
        </div>
      </div>

      <div class="md:col-span-3 flex justify-end gap-2">
        <div id="draftStatusBadge" class="px-4 py-2 rounded-xl text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200 flex items-center gap-2">
          <span class="w-2 h-2 rounded-full bg-amber-500 animate-ping"></span> Status: <span id="statusLabel">DRAFT</span>
        </div>

      </div>
    </div>

    <!-- Shared academic and Dean-rule context: selected once with the allocated course -->
    <div class="mt-5 pt-5 border-t border-slate-100" id="teachingCourseContext">
      <div class="flex flex-wrap items-center justify-between gap-2 mb-3">
        <div>
          <h4 class="text-xs font-black uppercase tracking-wider text-slate-700">Academic &amp; Dean Rule Context</h4>
          <p class="text-[11px] text-slate-400 mt-0.5">Select the context once here; the Final Question Slot Allocation uses these same values.</p>
        </div>
        <span id="slotRuleStatus" class="rounded-full px-3 py-1 text-xs font-bold bg-rose-100 text-rose-700">Select course context</span>
      </div>
      <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-4">
        <div>
          <label for="fieldAcademicYear" class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Select Academic Year</label>
          <select id="fieldAcademicYear" class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-semibold focus:ring-2 focus:ring-indigo-500 focus:bg-white">
            <?php
              $currentYear = (int)date('Y');
              $academicYears = [];
              for ($offset = -2; $offset <= 2; $offset++) {
                  $startYear = $currentYear + $offset;
                  $academicYears[] = $startYear . '-' . ($startYear + 1);
              }
              $defaultAcademicYear = defined('DEFAULT_ACADEMIC_YEAR') ? DEFAULT_ACADEMIC_YEAR : ($currentYear . '-' . ($currentYear + 1));
              foreach ($academicYears as $academicYearOption):
            ?>
              <option value="<?php echo htmlspecialchars($academicYearOption, ENT_QUOTES); ?>" <?php echo $academicYearOption === $defaultAcademicYear ? 'selected' : ''; ?>><?php echo htmlspecialchars($academicYearOption); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label for="fieldProgrammeYear" class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Year of Programme</label>
          <select id="fieldProgrammeYear" class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-semibold focus:ring-2 focus:ring-indigo-500 focus:bg-white">
            <?php foreach (qps_programme_levels() as $programmeLevelOption): ?>
              <option value="<?php echo htmlspecialchars($programmeLevelOption, ENT_QUOTES); ?>"><?php echo htmlspecialchars($programmeLevelOption); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label for="fieldSemester" class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Semester</label>
          <select id="fieldSemester" class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-semibold focus:ring-2 focus:ring-indigo-500 focus:bg-white">
            <?php foreach (qps_semester_options() as $semesterOption): ?><option value="<?= htmlspecialchars($semesterOption, ENT_QUOTES) ?>" <?= $semesterOption === 'Semester 1' ? 'selected' : '' ?>><?= htmlspecialchars($semesterOption) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div>
          <label for="fieldTotalMarks" class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Total Marks</label>
          <select id="fieldTotalMarks" data-no-search="true" required aria-describedby="fieldTotalMarksHelp" class="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-slate-800 font-semibold focus:ring-2 focus:ring-indigo-500 focus:border-indigo-400">
            <option value="">Select marks</option>
            <?php foreach ($allowedRuleMarks as $mark): ?><option value="<?= (int)$mark ?>"><?= (int)$mark ?> marks</option><?php endforeach; ?>
          </select>
          <p id="fieldTotalMarksHelp" class="mt-1 text-[10px] leading-4 text-slate-400">Select the course total. K-Level / CO-Level validation starts after selection.</p>
        </div>
        <div>
          <label for="fieldQuestionLanguage" class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Question Language</label>
          <select id="fieldQuestionLanguage" onchange="applyQuestionLanguage()" class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-semibold focus:ring-2 focus:ring-indigo-500 focus:bg-white">
            <option value="EN">English</option><option value="TL">Tamil</option><option value="HI">Hindi</option><option value="FR">French</option>
          </select>
        </div>
      </div>
    </div>

    <!-- Live Metric Cards -->
    <div class="qbank-metrics grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-100">
      <div class="bg-indigo-50/70 p-3.5 rounded-xl border border-indigo-100">
        <span class="text-[11px] font-bold text-indigo-600 uppercase">Total Questions</span>
        <div class="text-2xl font-black text-indigo-900 mt-1" id="statTotalQ">0</div>
        <span class="text-[10px] text-indigo-500 font-medium">In draft pool</span>
      </div>
      <div class="bg-blue-50/70 p-3.5 rounded-xl border border-blue-100">
        <span class="text-[11px] font-bold text-blue-600 uppercase">Sec A: 1M (MCQ)</span>
        <div class="text-2xl font-black text-blue-900 mt-1" id="statSecAMCQ">0</div>
        <span class="text-[10px] text-blue-500 font-medium">Target: 8+ Qs</span>
      </div>
      <div class="bg-cyan-50/70 p-3.5 rounded-xl border border-cyan-100">
        <span class="text-[11px] font-bold text-cyan-600 uppercase">Sec A: Match & AR</span>
        <div class="text-2xl font-black text-cyan-900 mt-1" id="statSecAMatchAR">0</div>
        <span class="text-[10px] text-cyan-500 font-medium">Q9 Match + Q10 AR</span>
      </div>
      <div class="bg-sky-50/70 p-3.5 rounded-xl border border-sky-100">
        <span class="text-[11px] font-bold text-sky-600 uppercase">Sec A: 1M (VSA)</span>
        <div class="text-2xl font-black text-sky-900 mt-1" id="statSecAVSA">0</div>
        <span class="text-[10px] text-sky-500 font-medium">Target: 10+ Qs (Q11-20)</span>
      </div>
      <div class="bg-amber-50/70 p-3.5 rounded-xl border border-amber-100">
        <span class="text-[11px] font-bold text-amber-600 uppercase">Sec B: 5M Pairs</span>
        <div class="text-2xl font-black text-amber-900 mt-1" id="statSecB">0</div>
        <span class="text-[10px] text-amber-500 font-medium">Target: 10+ Qs</span>
      </div>
      <div class="bg-emerald-50/70 p-3.5 rounded-xl border border-emerald-100">
        <span class="text-[11px] font-bold text-emerald-600 uppercase">Sec C/D: 10M</span>
        <div class="text-2xl font-black text-emerald-900 mt-1" id="statSecCD">0</div>
        <span class="text-[10px] text-emerald-500 font-medium">Sec C (4+) & D (1+)</span>
      </div>
      <div class="bg-rose-50/70 p-3.5 rounded-xl border border-rose-100" id="cardCorrections">
        <span class="text-[11px] font-bold text-rose-600 uppercase">Corrections</span>
        <div class="text-2xl font-black text-rose-700 mt-1" id="statCorrections">0</div>
        <span class="text-[10px] text-rose-500 font-medium">Needs revision</span>
      </div>
    </div>
  </div>

  <!-- Navigation Tabs -->
  <div class="qbank-tabs flex border-b border-slate-200">
    <button onclick="switchTab('entry')" id="tabBtn-entry" class="px-5 py-3 text-sm font-bold border-b-2 border-indigo-600 text-indigo-600 flex items-center gap-2 transition-all">
      <i data-lucide="plus-circle" class="w-4 h-4"></i> Question Entry Form
    </button>
    <button onclick="switchTab('blueprint')" id="tabBtn-blueprint" class="px-5 py-3 text-sm font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center gap-2 transition-all">
      <i data-lucide="grid" class="w-4 h-4"></i> Live Blueprint Matrix
    </button>
    <button onclick="switchTab('slots')" id="tabBtn-slots" class="px-5 py-3 text-sm font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center gap-2 transition-all">
      <i data-lucide="check-square" class="w-4 h-4"></i> Final Question Slot Allocation
    </button>
    <button onclick="switchTab('drafts')" id="tabBtn-drafts" class="px-5 py-3 text-sm font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center gap-2 transition-all">
      <i data-lucide="layers" class="w-4 h-4"></i> Draft Questions Pool (<span id="draftCountBadge">0</span>)
    </button>
    <button onclick="switchTab('allquestions')" id="tabBtn-allquestions" class="px-5 py-3 text-sm font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center gap-2 transition-all">
      <i data-lucide="library" class="w-4 h-4"></i> All Questions (<span id="allQuestionsCountBadge">0</span>)
    </button>
  </div>

  <!-- TAB 1: INTERACTIVE QUESTION ENTRY FORM -->
  <div id="tabContent-entry" class="space-y-6">
    <form id="questionForm" onsubmit="handleSaveQuestion(event)" class="bg-white rounded-2xl border border-slate-200/80 shadow-sm p-6 space-y-6">
      <input type="hidden" id="editQuestionId" value="0">

      <div class="flex items-center justify-between pb-4 border-b border-slate-100">
        <div class="flex items-center gap-2">
          <span class="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 font-bold flex items-center justify-center text-sm" id="formModeIcon">1</span>
          <div><h3 class="text-base font-bold text-slate-800" id="formModeTitle">Add New Question</h3><div class="mt-1 flex flex-wrap items-center gap-2"><p id="nextQuestionNumber" class="text-xs font-bold text-indigo-600">Next question number: 1</p><span id="totalQuestionCount" class="inline-flex items-center rounded-full bg-emerald-50 border border-emerald-200 px-2.5 py-1 text-[11px] font-black text-emerald-700">Total Questions: 0</span></div></div>
        </div>
        <button type="button" onclick="resetQuestionForm()" class="text-xs font-semibold text-slate-500 hover:text-slate-700 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 transition-all">
          <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i> Clear Form
        </button>
      </div>

      <!-- Correction Notice Banner (visible when editing a question that needs correction) -->
      <div id="correctionAlertBanner" class="hidden p-4 rounded-xl bg-amber-50 border border-amber-300 text-amber-900 text-sm flex items-start gap-3">
        <i data-lucide="alert-triangle" class="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5"></i>
        <div>
          <h5 class="font-bold">HOD Correction Remarks:</h5>
          <p id="correctionAlertText" class="mt-1 text-slate-700"></p>
        </div>
      </div>

      <!-- Row 1: Unit, Sub-Unit, Marks, Section & Question Type -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div>
          <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Unit <span class="text-rose-500">*</span></label>
          <select id="fieldUnit" onchange="updateSubunitOptions()" class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-semibold focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all">
            <option value="1">Unit I</option>
            <option value="2">Unit II</option>
            <option value="3">Unit III</option>
            <option value="4">Unit IV</option>
            <option value="5">Unit V</option>
          </select>
          <p id="unitQuestionCount" class="mt-1 text-[10px] font-bold text-indigo-600">0 questions in this unit</p>
        </div>

        <div>
          <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Sub-Unit <span class="text-rose-500">*</span></label>
          <div class="flex items-center gap-2">
            <select id="fieldSubUnit" onchange="syncCustomSubUnit()" class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-semibold focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all">
              <option value="1.1">1.1</option>
              <option value="1.2">1.2</option>
              <option value="1.3">1.3</option>
              <option value="1.4">1.4</option>
              <option value="1.5">1.5</option>
              <option value="1.6">1.6</option>
            </select>
          </div>
          <p id="subUnitQuestionCount" class="mt-1 text-[10px] font-bold text-indigo-600">0 questions in this sub-unit</p>
        </div>

        <div>
          <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Marks <span class="text-rose-500">*</span></label>
          <select id="fieldMarks" onchange="handleMarksChange()" class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-bold focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all">
            <option value="1">1 Mark</option>
            <option value="5">5 Marks</option>
            <option value="10">10 Marks</option>
          </select>
        </div>

        <div>
          <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Section <span class="text-rose-500">*</span></label>
          <select id="fieldSectionType" onchange="handleSectionChange()" class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-semibold focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all">
            <option value="SECTION-A">Section A (1 Mark Questions)</option>
            <option value="SECTION-B">Section B (5 Mark Questions)</option>
            <option value="SECTION-C">Section C (10 Mark Questions)</option>
            <option value="SECTION-D">Section D (10 Mark Compulsory)</option>
          </select>
        </div>

        <div>
          <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Question Type <span class="text-rose-500">*</span></label>
          <select id="fieldType" onchange="handleTypeChange()" class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-semibold focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all">
            <!-- Dynamically populated based on Marks & Section -->
          </select>
        </div>
      </div>

      <!-- Row 2: Bloom's Taxonomy & Course Outcome -->
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div>
          <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Bloom's Taxonomy (K-Level) <span class="text-rose-500">*</span></label>
          <select id="fieldKLevel" class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-semibold focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all">
            <option value="K1">K1 - Remember (Recall facts & basic concepts)</option>
            <option value="K2">K2 - Understand (Explain ideas or concepts)</option>
            <option value="K3">K3 - Apply (Use information in new situations)</option>
            <option value="K4">K4 - Analyze (Draw connections among ideas)</option>
            <option value="K5">K5 - Evaluate (Justify a stand or decision)</option>
            <option value="K6">K6 - Create (Produce new or original work)</option>
          </select>
        </div>

        <div>
          <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Course Outcome (CO) <span class="text-rose-500">*</span></label>
          <select id="fieldCOLevel" class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-semibold focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all">
            <option value="CO1">CO1</option>
            <option value="CO2">CO2</option>
            <option value="CO3">CO3</option>
            <option value="CO4">CO4</option>
            <option value="CO5">CO5</option>
          </select>
        </div>

        <div id="sectionDCheckboxContainer" class="hidden flex items-center pt-6">
          <label class="inline-flex items-center gap-2.5 cursor-pointer">
            <input type="checkbox" id="fieldIsCompulsory" class="w-5 h-5 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500">
            <span class="text-xs font-bold text-indigo-900 uppercase">Compulsory Question (Section D / Q29)</span>
          </label>
        </div>
      </div>

      <!-- Question Textarea with Math LaTeX Helper -->
      <div>
        <div class="flex items-center justify-between mb-1.5">
          <label class="block text-xs font-bold uppercase tracking-wider text-slate-600">Question Text <span class="text-rose-500">*</span></label>
          <div class="flex items-center gap-1.5 text-xs text-slate-500">
            <span>Insert Math:</span>
            <button type="button" onclick="insertLatex('\\sqrt{x}')" class="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-700 font-mono text-xs">√x</button>
            <button type="button" onclick="insertLatex('\\frac{a}{b}')" class="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-700 font-mono text-xs">a/b</button>
            <button type="button" onclick="insertLatex('\\sum_{i=1}^{n}')" class="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-700 font-mono text-xs">∑</button>
            <button type="button" onclick="insertLatex('\\int_{a}^{b}')" class="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-700 font-mono text-xs">∫</button>
            <button type="button" onclick="insertLatex('\\theta')" class="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-700 font-mono text-xs">θ</button>
          </div>
        </div>
        <textarea id="fieldQuestionText" oninput="renderMathPreview()" rows="3" placeholder="Enter the complete question statement here. For formulas use LaTeX: $E=mc^2$ or $\frac{a}{b}$..." class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all font-sans text-sm"></textarea>
        <!-- Math Live Preview -->
        <div id="mathPreviewBox" class="mt-2 p-3 bg-slate-50 rounded-xl border border-slate-200/60 text-xs text-slate-600 hidden">
          <span class="font-bold text-slate-400 block mb-1">Live Math Preview:</span>
          <div id="mathPreviewContent" class="text-slate-900 text-sm"></div>
        </div>
      </div>

      <!-- SPECIFIC QUESTION TYPE SUB-CONTAINERS -->

      <!-- 1. MCQ OPTIONS (A, B, C, D) -->
      <div id="containerMCQ" class="space-y-3 bg-slate-50/70 p-4 rounded-xl border border-slate-200/80">
        <label class="block text-xs font-bold uppercase tracking-wider text-slate-600">Multiple Choice Options (A, B, C, D) & Answer Key</label>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div class="flex items-center gap-2">
            <span class="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center text-xs flex-shrink-0">A</span>
            <input type="text" id="mcqOptA" placeholder="Option A text..." class="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-800">
          </div>
          <div class="flex items-center gap-2">
            <span class="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center text-xs flex-shrink-0">B</span>
            <input type="text" id="mcqOptB" placeholder="Option B text..." class="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-800">
          </div>
          <div class="flex items-center gap-2">
            <span class="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center text-xs flex-shrink-0">C</span>
            <input type="text" id="mcqOptC" placeholder="Option C text..." class="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-800">
          </div>
          <div class="flex items-center gap-2">
            <span class="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center text-xs flex-shrink-0">D</span>
            <input type="text" id="mcqOptD" placeholder="Option D text..." class="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-800">
          </div>
        </div>
        <div class="flex items-center gap-3 pt-2">
          <span class="text-xs font-bold text-slate-600 uppercase">Correct Option:</span>
          <div class="flex items-center gap-4 text-sm font-semibold">
            <label class="inline-flex items-center gap-1.5 cursor-pointer"><input type="radio" name="mcqCorrect" value="A" checked onchange="syncAnswerKeyField()" class="text-indigo-600"> Option A</label>
            <label class="inline-flex items-center gap-1.5 cursor-pointer"><input type="radio" name="mcqCorrect" value="B" onchange="syncAnswerKeyField()" class="text-indigo-600"> Option B</label>
            <label class="inline-flex items-center gap-1.5 cursor-pointer"><input type="radio" name="mcqCorrect" value="C" onchange="syncAnswerKeyField()" class="text-indigo-600"> Option C</label>
            <label class="inline-flex items-center gap-1.5 cursor-pointer"><input type="radio" name="mcqCorrect" value="D" onchange="syncAnswerKeyField()" class="text-indigo-600"> Option D</label>
          </div>
        </div>
      </div>

      <!-- 2. MATCH THE FOLLOWING (Column A & Column B) -->
      <div id="containerMatch" class="hidden space-y-3 bg-slate-50/70 p-4 rounded-xl border border-slate-200/80">
        <label class="block text-xs font-bold uppercase tracking-wider text-slate-600">Match Following Pairs (Column A & Column B)</label>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div><span class="text-xs font-bold text-slate-500 uppercase">Column A</span><div id="matchColumnA" class="space-y-2 mt-2"></div><button type="button" onclick="addMatchRow()" class="mt-2 px-3 py-2 rounded-lg bg-indigo-50 text-indigo-700 text-xs font-bold">+ Add Row</button></div>
          <div><span class="text-xs font-bold text-slate-500 uppercase">Column B (includes one extra option)</span><div id="matchColumnB" class="space-y-2 mt-2"></div><button type="button" onclick="addMatchOption()" class="mt-2 px-3 py-2 rounded-lg bg-sky-50 text-sky-700 text-xs font-bold">+ Add Option</button></div>
        </div>
        <div class="mt-3"><span class="text-xs font-bold text-slate-500 uppercase">Assign Column B options to Column A</span><div id="matchAssignments" class="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2"></div><p class="text-xs text-indigo-700 mt-2">Answer key: <strong id="matchAnswerKeyPreview">—</strong></p></div>

      </div>

      <!-- 3. ASSERTION & REASON -->
      <div id="containerAR" class="hidden space-y-3 bg-slate-50/70 p-4 rounded-xl border border-slate-200/80">
        <label class="block text-xs font-bold uppercase tracking-wider text-slate-600">Assertion & Reason Details</label>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label class="block text-xs font-semibold text-slate-600 mb-1">Assertion (A):</label>
            <textarea id="arAssertionText" rows="2" placeholder="State Assertion (A)..." class="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm"></textarea>
          </div>
          <div>
            <label class="block text-xs font-semibold text-slate-600 mb-1">Reason (R):</label>
            <textarea id="arReasonText" rows="2" placeholder="State Reason (R)..." class="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm"></textarea>
          </div>
        </div>
      </div>

      <!-- Row 4: Diagram / Image Attachment & Answer Key -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Diagram / Image Attachment (Optional)</label>
          <div class="flex items-center gap-3">
            <input type="file" id="diagramFileInput" accept="image/*" onchange="uploadDiagramFile(this)" class="block w-full text-xs text-slate-500 file:mr-3 file:py-2 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
            <input type="hidden" id="fieldImageUrl" value="">
          </div>
          <div id="diagramPreviewContainer" class="hidden mt-2 relative inline-block">
            <img id="diagramPreviewImg" src="" alt="Diagram Preview" class="h-20 w-auto rounded-lg border border-slate-200 shadow-sm object-contain bg-white p-1">
            <button type="button" onclick="removeDiagram()" class="absolute -top-2 -right-2 w-5 h-5 bg-rose-600 text-white rounded-full flex items-center justify-center text-xs shadow-md">✕</button>
          </div>
        </div>

        <div>
          <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Answer Key / Model Points (Optional)</label>
          <input type="text" id="fieldAnswerKey" readonly aria-readonly="true" placeholder="Answer key is generated from the selected correct option..." class="w-full px-3.5 py-2 bg-slate-100 border border-slate-200 rounded-xl text-slate-800 text-sm cursor-not-allowed">
          <p class="mt-1 text-[10px] text-slate-500">Read-only: saved automatically from the selected MCQ answer or matching assignments.</p>
        </div>
      </div>

      <!-- Action Buttons -->
      <div class="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
        <button type="button" onclick="resetQuestionForm()" class="px-5 py-2.5 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-100 transition-all">Cancel</button>
        <button type="submit" id="btnSaveQuestion" class="px-6 py-2.5 rounded-xl text-sm font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg shadow-indigo-200 flex items-center gap-2 transition-all">
          <i data-lucide="save" class="w-4 h-4"></i> Save Question to Bank Draft
        </button>
      </div>
    </form>
  </div>

  <!-- TAB 2: LIVE QUESTION BANK BLUEPRINT MATRIX -->
  <div id="tabContent-blueprint" class="hidden space-y-6">
    <div class="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
      <div class="p-6 bg-slate-900 text-white flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider">
            <i data-lucide="matrix" class="w-4 h-4"></i> Live Compiled Question Bank Blueprint
          </div>
          <h2 class="text-xl font-bold tracking-tight mt-0.5" id="blueprintHeaderTitle">Course Blueprint Matrix</h2>
          <p class="text-xs text-slate-400 mt-1">Populated simultaneously as questions are entered. Conforms to Holy Cross College 75-mark standard.</p>
        </div>
        <div class="flex items-center gap-3">
          <span class="px-3 py-1.5 rounded-lg bg-slate-800 text-emerald-400 text-xs font-mono font-bold border border-slate-700">
            Total Marks in Pool: <span id="blueprintTotalMarks">0</span> M
          </span>
          <button type="button" onclick="switchTab('slots')" class="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md flex items-center gap-1.5 transition">
            <i data-lucide="check-square" class="w-4 h-4"></i> Configure Exam Slots &rarr;
          </button>
        </div>
      </div>

      <!-- Blueprint Table Matching sample-blueprint.jpeg -->
      <div class="overflow-x-auto">
        <table class="w-full border-collapse text-center text-xs" id="blueprintMatrixTable">
          <thead>
            <!-- Group Header Row -->
            <tr class="bg-slate-100 border-b border-slate-300 font-bold text-slate-700">
              <th rowspan="2" class="p-2 border-r border-slate-300 w-16">Unit</th>
              <th rowspan="2" class="p-2 border-r border-slate-300 w-16">Sub Unit</th>
              <th colspan="3" class="p-2 border-r border-slate-300 bg-blue-50/70 text-blue-900">MC (1M)</th>
              <th colspan="3" class="p-2 border-r border-slate-300 bg-sky-50/70 text-sky-900">V.S.A (1M)</th>
              <th colspan="3" class="p-2 border-r border-slate-300 bg-amber-50/70 text-amber-900">Section B (5M)</th>
              <th colspan="3" class="p-2 border-r border-slate-300 bg-emerald-50/70 text-emerald-900">Section C (10M)</th>
              <th colspan="2" class="p-2 border-r border-slate-300 bg-purple-50/70 text-purple-900">Section D (10M)</th>
              <th rowspan="2" class="p-2 border-r border-slate-300 bg-slate-200 text-slate-800">Total Qs</th>
              <th rowspan="2" class="p-2 bg-slate-200 text-slate-800 font-extrabold">Total Marks</th>
            </tr>
            <!-- Sub Column Header Row -->
            <tr class="bg-slate-50 border-b border-slate-300 font-bold text-[11px] text-slate-600">
              <!-- MC -->
              <th class="p-1.5 border-r border-slate-300 bg-blue-50/40">K1</th>
              <th class="p-1.5 border-r border-slate-300 bg-blue-50/40">K2</th>
              <th class="p-1.5 border-r border-slate-300 bg-blue-100/60 font-extrabold text-blue-900">Tot</th>
              <!-- VSA -->
              <th class="p-1.5 border-r border-slate-300 bg-sky-50/40">K1</th>
              <th class="p-1.5 border-r border-slate-300 bg-sky-50/40">K2</th>
              <th class="p-1.5 border-r border-slate-300 bg-sky-100/60 font-extrabold text-sky-900">Tot</th>
              <!-- Sec B -->
              <th class="p-1.5 border-r border-slate-300 bg-amber-50/40">K3</th>
              <th class="p-1.5 border-r border-slate-300 bg-amber-50/40">K4</th>
              <th class="p-1.5 border-r border-slate-300 bg-amber-100/60 font-extrabold text-amber-900">Tot</th>
              <!-- Sec C -->
              <th class="p-1.5 border-r border-slate-300 bg-emerald-50/40">K5</th>
              <th class="p-1.5 border-r border-slate-300 bg-emerald-50/40">K6</th>
              <th class="p-1.5 border-r border-slate-300 bg-emerald-100/60 font-extrabold text-emerald-900">Tot</th>
              <!-- Sec D -->
              <th class="p-1.5 border-r border-slate-300 bg-purple-50/40">K6</th>
              <th class="p-1.5 border-r border-slate-300 bg-purple-100/60 font-extrabold text-purple-900">Tot</th>
            </tr>
          </thead>
          <tbody id="blueprintMatrixBody" class="divide-y divide-slate-200">
            <!-- Dynamic Sub-unit Rows (1.1 through 5.4) rendered via JS -->
          </tbody>
          <tfoot id="blueprintMatrixFoot" class="bg-slate-100 font-extrabold text-slate-900 border-t-2 border-slate-400">
            <!-- Totals Row rendered via JS -->
          </tfoot>
        </table>
      </div>
    </div>
  </div>

  <!-- TAB 3: FINAL QUESTION SLOT ALLOCATION (MASTER BLUEPRINT SPECIFICATION) -->
  <div id="tabContent-slots" class="hidden space-y-6">
    <div class="bg-white rounded-2xl border border-slate-200/80 shadow-sm p-6 space-y-6">
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div>
          <div class="flex items-center gap-2">
            <span class="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 font-bold flex items-center justify-center text-sm">📋</span>
            <h3 class="text-base font-bold text-slate-800">Final Question Slot Allocation (Master Blueprint Specification)</h3>
          </div>
          <p class="text-xs text-slate-500 mt-1">The selected published Dean template defines sections, question slots and marks. K-Level and CO-Level are checked against the Dean question rules. Teaching staff assign Unit, Sub-unit and Question Type.</p>
        </div>

        <div class="w-full md:w-[360px]">
          <label for="deanTemplateSelect" class="block text-xs font-bold text-slate-600 mb-1">Published Dean Template</label>
          <select id="deanTemplateSelect" onchange="loadSelectedDeanTemplate(this.value)" class="w-full rounded-xl border-slate-300 bg-white p-3 text-sm font-semibold">
            <option value="">Select Academic Year, Year of Programme and Total Marks first</option>
          </select>
          <p id="deanTemplateStatus" class="mt-1 text-[11px] text-slate-500">Only published templates matching the selected context will appear.</p>
        </div>
      </div>


      <!-- Slot Allocation Summary Banner -->
      <div class="grid grid-cols-1 sm:grid-cols-4 gap-3">
        <div class="p-3.5 bg-slate-50 rounded-xl border border-slate-200/70">
          <span class="text-[11px] font-bold text-slate-500 uppercase">Total-Marks Format</span>
          <div class="text-lg font-black text-slate-900 mt-0.5" id="slotPatternText">Select marks to load slots</div>
        </div>
        <div class="p-3.5 bg-emerald-50 rounded-xl border border-emerald-200/70">
          <span class="text-[11px] font-bold text-emerald-700 uppercase">Configured Slots</span>
          <div class="text-lg font-black text-emerald-900 mt-0.5" id="slotAllocatedCount">30 / 30 Configured</div>
        </div>
        <div class="p-3.5 bg-blue-50 rounded-xl border border-blue-200/70">
          <span class="text-[11px] font-bold text-blue-700 uppercase">Total Marks</span>
          <div class="text-lg font-black text-blue-900 mt-0.5" id="slotTotalMarksSummary">Select marks</div>
        </div>
        <div class="p-3.5 bg-indigo-50 rounded-xl border border-indigo-200/70">
          <span class="text-[11px] font-bold text-indigo-700 uppercase">Blueprint Status</span>
          <div class="text-lg font-black text-emerald-600 mt-0.5" id="slotValidationStatus">ACTIVE SPECIFICATION</div>
        </div>
      </div>

      <!-- Confidential Notice Banner for Teaching Staff -->
      <div class="bg-indigo-50/60 border border-indigo-200 rounded-xl p-3 flex items-center justify-between text-xs text-indigo-900">
        <div class="flex items-center space-x-2">
          <i data-lucide="shield" class="w-4 h-4 text-indigo-600 shrink-0"></i>
          <span><strong>Confidentiality Rule:</strong> Teaching staff configure slot parameters alone (Unit, Subunit, Type, Marks, K/CO levels). Question text is hidden to ensure impartial exam paper compilation.</span>
        </div>
        <span class="text-[11px] font-mono font-bold text-indigo-700 bg-white px-2.5 py-0.5 rounded-full border border-indigo-200">Marks-based slot validation</span>
      </div>

      <!-- Entered Units Pool Information Banner -->
      <div id="enteredUnitsBanner" class="p-3.5 bg-indigo-50/80 border border-indigo-200 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-indigo-950">
        <div class="flex items-center space-x-2.5">
          <span class="w-6 h-6 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shrink-0">🎯</span>
          <span id="enteredUnitsBannerText">Loading entered questions units...</span>
        </div>
        <span class="text-[11px] font-bold text-indigo-700 bg-white px-3 py-1 rounded-full border border-indigo-200 shadow-sm self-start sm:self-auto shrink-0" id="enteredUnitsBadge">Entered Units Only</span>
      </div>

      <!-- Interactive Question Slots Container Grouped by Section Colors -->
      <div id="slotsGridContainer" class="space-y-6">
        <!-- Rendered dynamically by renderSlotAllocationTable() -->
      </div>
    </div>
  </div>

  <!-- TAB 4: DRAFT QUESTIONS POOL & CORRECTIONS -->
  <div id="tabContent-drafts" class="hidden space-y-6">
    <div class="bg-white rounded-2xl border border-slate-200/80 shadow-sm p-6">
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-slate-100">
        <div>
          <h3 class="text-base font-bold text-slate-800">Draft Questions Pool</h3>
          <p class="text-xs text-slate-500">Questions grouped by Unit · edit or delete draft questions before submission</p>
        </div>
        <div class="flex flex-wrap items-center gap-3">
          <button id="btnSubmitHod" onclick="submitBankToHOD()" class="px-4 py-2.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-md shadow-indigo-200 flex items-center gap-2 transition-all">
            <i data-lucide="send" class="w-4 h-4"></i> Submit to HOD
          </button>
          <select id="filterSection" onchange="renderQuestionsList()" class="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold">
            <option value="ALL">All Sections</option>
            <option value="SECTION-A">Section A (1M)</option>
            <option value="SECTION-B">Section B (5M)</option>
            <option value="SECTION-C">Section C (10M)</option>
            <option value="SECTION-D">Section D (10M Compulsory)</option>
          </select>
          <select id="filterCorrection" onchange="renderQuestionsList()" class="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold">
            <option value="ALL">All Statuses</option>
            <option value="NEEDS_CORRECTION">⚠️ Needs Correction</option>
            <option value="CLEAN">✅ Clean</option>
          </select>
        </div>
      </div>

      <!-- Questions Container -->
      <div id="draftQuestionsList" class="mt-4 space-y-3">
        <!-- Rendered via JS -->
      </div>

      <!-- Combined question preview: attached image and MATCH table -->
      <div id="questionImageModal" class="hidden fixed inset-0 z-[1010] items-center justify-center bg-slate-950/70 p-4" onclick="if(event.target===this)closeQuestionImagePreview()">
        <div class="bg-white w-full max-w-5xl max-h-[92vh] overflow-hidden rounded-2xl shadow-2xl flex flex-col" role="dialog" aria-modal="true" aria-labelledby="questionImageTitle">
          <div class="flex items-center justify-between gap-3 p-4 border-b shrink-0">
            <div><h3 id="questionImageTitle" class="font-bold text-slate-800">Question Preview</h3><p class="text-xs text-slate-500">Question details, matching answers and attachment</p></div>
            <button type="button" onclick="closeQuestionImagePreview()" class="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 text-xl" aria-label="Close">×</button>
          </div>
          <div id="questionPreviewContent" class="p-4 overflow-y-auto space-y-4"></div>
          <div class="flex justify-end p-3 border-t shrink-0"><button type="button" onclick="closeQuestionImagePreview()" class="px-4 py-2 rounded-lg border text-sm font-semibold">Close</button></div>
        </div>
      </div>
    </div>
  </div>

  <!-- TAB 5: ALL QUESTIONS (DRAFT + COE APPROVED) -->
  <div id="tabContent-allquestions" class="hidden space-y-6">
    <div class="bg-white rounded-2xl border border-slate-200/80 shadow-sm p-6">
      <div class="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4 pb-4 border-b border-slate-100">
        <div><h3 class="text-base font-bold text-slate-800">All Questions</h3><p class="text-xs text-slate-500">Draft questions and questions from COE-approved banks for this course</p></div>
        <div class="flex flex-wrap gap-2">
          <input id="allQSearch" oninput="allQPage=1;renderAllQuestions()" type="search" placeholder="Search question..." class="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs w-48">
          <select id="allQStatus" onchange="allQPage=1;renderAllQuestions()" class="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"><option value="ALL">All statuses</option><option value="DRAFT">Draft</option><option value="COE_APPROVED">COE Approved</option></select>
          <select id="allQSection" onchange="allQPage=1;renderAllQuestions()" class="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"><option value="ALL">All sections</option><option value="SECTION-A">Section A</option><option value="SECTION-B">Section B</option><option value="SECTION-C">Section C</option><option value="SECTION-D">Section D</option></select>
          <select id="allQType" onchange="allQPage=1;renderAllQuestions()" class="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"><option value="ALL">All types</option><option value="MCQ">MCQ</option><option value="MATCH">Match</option><option value="VSA">VSA</option><option value="AR">Assertion & Reason</option></select>
        </div>
      </div>
      <div id="allQuestionsList" class="mt-4"></div>
      <div id="allQuestionsPagination" class="mt-4 flex flex-wrap items-center justify-between gap-3"></div>
    </div>
  </div>

</div>

<script>
// Global HTML Escape Helper
function escapeHtml(str) {
  return String(str ?? '').replace(/[&<>'"]/g, tag => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    "'": '&#39;',
    '"': '&quot;'
  }[tag] || tag));
}

// State Management
let currentCourseCode = '<?php echo htmlspecialchars($selectedCourseCode); ?>';
let currentDraft = null;
let currentFinalBlueprintId = 0;
let currentQuestions = [];
let currentMatrix = [];
let coeApprovedQuestions = [];
let allQPage = 1;
const ALL_Q_PAGE_SIZE = 10;

document.addEventListener('DOMContentLoaded', () => {
  if (currentCourseCode) {
    loadCourseData(currentCourseCode);
  }

  document.getElementById('courseSelect').addEventListener('change', function() {
    currentCourseCode = this.value;
    const totalMarksSelect = document.getElementById('fieldTotalMarks');
    if (totalMarksSelect) {
      totalMarksSelect.disabled = false;
      totalMarksSelect.value = '';
    }
    slotRuleCount = 0;
    slotRuleError = 'Select Total Marks to validate K-Level and CO-Level rules.';
    setSlotRuleStatus(slotRuleError, false);
    currentSlotsData = (Array.isArray(currentSlotsData) ? currentSlotsData : []).map(slot => ({...slot, k_level:'', co_level:''}));
    loadCourseData(currentCourseCode);
  });
  ['fieldAcademicYear','fieldProgrammeYear','fieldSemester','fieldTotalMarks','fieldQuestionLanguage'].forEach(id => {
    document.getElementById(id)?.addEventListener('change', saveTeachingContext);
  });
  ['fieldAcademicYear','fieldProgrammeYear','fieldTotalMarks'].forEach(id => {
    document.getElementById(id)?.addEventListener('change', () => { clearDeanTemplateState('Context changed. Select a matching Dean template again.'); refreshDeanTemplates(); });
  });

  handleMarksChange();
  updateSubunitOptions();
  lucide.createIcons();
});

function switchTab(tabId) {
  ['entry', 'blueprint', 'slots', 'drafts', 'allquestions'].forEach(t => {
    const el = document.getElementById(`tabContent-${t}`);
    if (el) el.classList.add('hidden');
    const btn = document.getElementById(`tabBtn-${t}`);
    if (btn) {
      btn.classList.remove('border-indigo-600', 'text-indigo-600');
      btn.classList.add('border-transparent', 'text-slate-500');
    }
  });

  const activeContent = document.getElementById(`tabContent-${tabId}`);
  if (activeContent) activeContent.classList.remove('hidden');
  const activeBtn = document.getElementById(`tabBtn-${tabId}`);
  if (activeBtn) {
    activeBtn.classList.remove('border-transparent', 'text-slate-500');
    activeBtn.classList.add('border-indigo-600', 'text-indigo-600');
  }

  if (tabId === 'blueprint') {
    renderBlueprintMatrix();
  } else if (tabId === 'slots') {
    renderSlotAllocationTable();
  } else if (tabId === 'drafts') {
    renderQuestionsList();
  } else if (tabId === 'allquestions') {
    loadAllQuestions();
  }
}

// ----------------------------------------------------
// FINAL QUESTION SLOT ALLOCATION & MASTER BLUEPRINT ENGINE
// ----------------------------------------------------
let currentSlotsData = [];
let activeSlotNumber = null;
let currentDeanTemplateId = 0;
let currentDeanTemplateName = "";
let deanTemplateRequestSeq = 0;

// Extract unique entered units & sub-units strictly from the draft questions pool
function getEnteredUnitsAndSubunits() {
  const unitMap = {};
  
  if (Array.isArray(currentQuestions) && currentQuestions.length > 0) {
    currentQuestions.forEach(q => {
      const u = parseInt(q.unit_no, 10);
      const sub = String(q.sub_unit || `${u}.1`).trim();
      if (!isNaN(u) && u >= 1) {
        if (!unitMap[u]) unitMap[u] = new Set();
        unitMap[u].add(sub);
      }
    });
  }

  if (Array.isArray(currentMatrix) && currentMatrix.length > 0) {
    currentMatrix.forEach(row => {
      const u = parseInt(row.unit, 10);
      const sub = String(row.sub_unit || `${u}.1`).trim();
      if (!isNaN(u) && u >= 1) {
        if (!unitMap[u]) unitMap[u] = new Set();
        unitMap[u].add(sub);
      }
    });
  }

  const sortedUnits = Object.keys(unitMap).map(Number).sort((a,b) => a - b);
  
  if (sortedUnits.length === 0) {
    // If no questions entered yet in draft pool, provide standard fallback units 1-5
    return {
      isFallback: true,
      units: [1, 2, 3, 4, 5],
      subunitsByUnit: {
        1: ['1.1', '1.2', '1.3', '1.4', '1.5'],
        2: ['2.1', '2.2', '2.3', '2.4', '2.5'],
        3: ['3.1', '3.2', '3.3', '3.4', '3.5'],
        4: ['4.1', '4.2', '4.3', '4.4', '4.5'],
        5: ['5.1', '5.2', '5.3', '5.4', '5.5']
      }
    };
  }

  const subunitsByUnit = {};
  sortedUnits.forEach(u => {
    subunitsByUnit[u] = Array.from(unitMap[u]).sort((a,b) => {
      const na = parseFloat(a) || 0;
      const nb = parseFloat(b) || 0;
      return na - nb || a.localeCompare(b);
    });
  });

  return {
    isFallback: false,
    units: sortedUnits,
    subunitsByUnit: subunitsByUnit
  };
}

function getDefaultSlotTemplates() {
  // Legacy marks-based layouts are intentionally disabled. Only a published
  // Dean template may define the slot structure.
  return [];
}

// Render the question-number navigator. Only the selected slot editor is rendered.
function renderSlotCirclesBar() {
  const bar = document.getElementById('slotQuickCirclesStrip');
  if (!bar) return;
  if (!currentSlotsData.length) { bar.innerHTML = '<p class="text-xs text-slate-500">No Dean template selected.</p>'; return; }
  if (!currentSlotsData.some(s => Number(s.slot_number) === Number(activeSlotNumber))) {
    activeSlotNumber = currentSlotsData[0]?.slot_number ?? null;
  }
  const sectionColors = {
    'SECTION-A': 'bg-indigo-600 border-indigo-400 text-white',
    'SECTION-B': 'bg-amber-400 border-amber-300 text-slate-950',
    'SECTION-C': 'bg-emerald-600 border-emerald-400 text-white',
    'SECTION-D': 'bg-rose-600 border-rose-400 text-white'
  };
  bar.innerHTML = currentSlotsData.map(slot => {
    const n = Number(slot.slot_number);
    const active = n === Number(activeSlotNumber);
    const saved = slot.is_saved === true || (slot.is_saved !== false && !!currentFinalBlueprintId);
    const savedColors = {'SECTION-A':'bg-indigo-950 border-indigo-700 text-white','SECTION-B':'bg-amber-950 border-amber-700 text-white','SECTION-C':'bg-emerald-950 border-emerald-700 text-white','SECTION-D':'bg-rose-950 border-rose-700 text-white'};
    return `<button type="button" onclick="selectBlueprintSlot(${n})" aria-pressed="${active}" title="Q${n} · ${escapeHtml(slot.section_type)} · ${Number(slot.marks || 1)} mark(s)${saved?' · SAVED':''}${slot.remark_text?' · REMARK: '+escapeHtml(slot.remark_text):''}" class="w-10 h-10 rounded-full border-2 font-black text-xs inline-flex items-center justify-center transition ${saved?(savedColors[slot.section_type]||'bg-slate-950 border-slate-700 text-white'):(slot.remark_text?'bg-rose-100 border-rose-500 text-rose-800':(sectionColors[slot.section_type] || 'bg-slate-500 text-white border-slate-400'))} ${active ? 'ring-4 ring-orange-300 scale-110 shadow-lg' : 'opacity-85 hover:opacity-100 hover:scale-105'}">${n}</button>`;
  }).join('');
}

function selectBlueprintSlot(slotNum) {
  activeSlotNumber = Number(slotNum);
  renderSlotAllocationTable();
}

function scrollToSlot(slotNum) { selectBlueprintSlot(slotNum); }

// Slot Unit Selection Change: updates unit and resets sub-unit to entered pool options
function updateSlotUnit(slotNum, newUnit) {
  const slot = currentSlotsData.find(s => parseInt(s.slot_number, 10) === parseInt(slotNum, 10));
  if (!slot) return;

  const u = parseInt(newUnit, 10) || 1;
  slot.unit_no = u;
  slot.is_saved = false;

  const pool = getEnteredUnitsAndSubunits();
  const availableSubunits = pool.subunitsByUnit[u] || [`${u}.1`];
  if (!availableSubunits.includes(slot.sub_unit)) {
    slot.sub_unit = availableSubunits[0] || `${u}.1`;
  }

  renderSlotAllocationTable();
}

// Slot Subunit Selection Change
function updateSlotSubUnit(slotNum, newSubUnit) {
  const slot = currentSlotsData.find(s => parseInt(s.slot_number, 10) === parseInt(slotNum, 10));
  if (!slot) return;
  slot.sub_unit = newSubUnit;
  slot.is_saved = false;
  renderSlotAllocationTable();
}

// Slot Generic Field Update
function updateSlotField(slotNum, field, val) {
  const slot = currentSlotsData.find(s => parseInt(s.slot_number, 10) === parseInt(slotNum, 10));
  if (slot) {
    slot.is_saved = false;
    if (field === 'marks') {
      slot.marks = parseInt(val, 10) || 1;
    } else {
      slot[field] = val;
    }
    renderSlotAllocationTable();
  }
}

function applyStandardSlotBlueprint() {
  Swal.fire({icon:'info', title:'Dean template required', text:'Select a published Dean template. Teaching Staff cannot generate a marks-based slot layout.'});
}

function getSlotMatchingDraftQuestions(slot) {
  if (!slot) return [];
  const requiredK = String(slot.k_level || '').trim().toUpperCase();
  const requiredCO = String(slot.co_level || '').trim().toUpperCase();
  if (!requiredK || !requiredCO) return [];
  return currentQuestions.filter(q =>
    Number(q.unit_no) === Number(slot.unit_no) &&
    String(q.sub_unit || '').trim() === String(slot.sub_unit || '').trim() &&
    Number(q.marks) === Number(slot.marks) &&
    String(q.k_level || '').trim().toUpperCase() === requiredK &&
    String(q.co_level || '').trim().toUpperCase() === requiredCO &&
    (!slot.question_type || String(q.question_type || '').trim().toUpperCase() === String(slot.question_type).trim().toUpperCase())
  );
}

function renderSlotAllocationTable() {
  const container = document.getElementById('slotsGridContainer');
  if (!container) return;
  if (!currentSlotsData.length) { container.innerHTML = '<div class="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">Select a published Dean template to load the approved question slots.</div>'; return; }
  const pool = getEnteredUnitsAndSubunits();
  if (!currentSlotsData.some(s => Number(s.slot_number) === Number(activeSlotNumber))) {
    activeSlotNumber = currentSlotsData[0]?.slot_number ?? null;
  }

  const totalSlots = currentSlotsData.length;
  const selectedMarks = Number(document.getElementById('fieldTotalMarks')?.value || 0);
  const countEl = document.getElementById('slotAllocatedCount');
  const marksSummaryEl = document.getElementById('slotTotalMarksSummary');
  const patternEl = document.getElementById('slotPatternText');
  const statusEl = document.getElementById('slotValidationStatus');
  if (countEl) countEl.innerText = totalSlots ? `${totalSlots} / ${totalSlots} Slots` : 'Select Total Marks';
  if (marksSummaryEl) marksSummaryEl.innerText = selectedMarks > 0 ? `${selectedMarks} Marks` : 'Select marks';
  if (patternEl) patternEl.innerText = selectedMarks > 0 ? `${selectedMarks} Marks · ${totalSlots} Questions` : 'Select marks to load slots';
  if (statusEl) { statusEl.innerText = 'ACTIVE SPECIFICATION'; statusEl.className = 'text-lg font-black text-emerald-600 mt-0.5'; }

  const bannerText = document.getElementById('enteredUnitsBannerText');
  const bannerBadge = document.getElementById('enteredUnitsBadge');
  if (bannerText && bannerBadge) {
    if (!pool.isFallback) {
      const unitsText = pool.units.map(u => `Unit ${['I','II','III','IV','V'][u-1] || u} (${currentQuestions.filter(q => Number(q.unit_no) === u).length} Qs)`).join(', ');
      bannerText.innerHTML = `<span><strong>Entered Question Units Active:</strong> ${unitsText}. Dropdowns contain units and sub-units found in the draft pool.</span>`;
      bannerBadge.innerText = `${pool.units.length} Units from Draft Pool`;
    } else {
      bannerText.innerHTML = '<span><strong>Draft Pool Notice:</strong> No questions entered yet. Standard units I–V are shown until questions are added.</span>';
      bannerBadge.innerText = 'Default Units I–V';
    }
  }

  renderSlotCirclesBar();
  const slot = currentSlotsData.find(s => Number(s.slot_number) === Number(activeSlotNumber));
  if (!slot) { container.innerHTML = '<p class="text-sm text-slate-500">No blueprint slots available.</p>'; return; }

  const units = pool.units.length ? pool.units : [1,2,3,4,5];
  const roman = u => ['I','II','III','IV','V'][Number(u)-1] || u;
  const unitOptions = units.map(u => `<option value="${u}" ${Number(slot.unit_no)===Number(u)?'selected':''}>Unit ${roman(u)} (${currentQuestions.filter(q=>Number(q.unit_no)===Number(u)).length} Qs)</option>`).join('');
  const chosenUnit = Number(slot.unit_no) || units[0] || 1;
  const subunits = pool.subunitsByUnit[chosenUnit] || [`${chosenUnit}.1`];
  if (!subunits.includes(String(slot.sub_unit))) slot.sub_unit = subunits[0];
  const subOptions = subunits.map(sub => `<option value="${escapeHtml(sub)}" ${String(slot.sub_unit)===String(sub)?'selected':''}>Sub-unit ${escapeHtml(sub)} (${currentQuestions.filter(q=>Number(q.unit_no)===chosenUnit && String(q.sub_unit).trim()===String(sub)).length} Qs)</option>`).join('');
  const matched = getSlotMatchingDraftQuestions(slot).length;
  const sectionStyles = {'SECTION-A':'border-indigo-200 bg-indigo-50 text-indigo-800','SECTION-B':'border-amber-200 bg-amber-50 text-amber-800','SECTION-C':'border-emerald-200 bg-emerald-50 text-emerald-800','SECTION-D':'border-rose-200 bg-rose-50 text-rose-800'};
  const secStyle = slot.remark_text ? 'border-rose-300 bg-rose-50 text-rose-800' : (sectionStyles[slot.section_type] || 'border-slate-200 bg-slate-50 text-slate-800');
  const isSlotSaved = slot.is_saved === true || (slot.is_saved !== false && !!currentFinalBlueprintId);
  const savedSectionBg = isSlotSaved ? 'bg-white text-white border-slate-700' : 'bg-white';

  container.innerHTML = `
    <div class="grid grid-cols-1 lg:grid-cols-[minmax(210px,.65fr)_minmax(0,1.7fr)] gap-4 items-start">
      <aside class="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm lg:sticky lg:top-4">
        <h4 class="font-black text-slate-900">Question slots</h4><p class="text-xs text-slate-500 mt-1">Select a numbered circle to edit only that slot.</p>
        <div class="mt-4 space-y-3">${Array.from(new Set(currentSlotsData.map(x=>x.section_type))).map(sec=>{
          const arr=currentSlotsData.filter(x=>x.section_type===sec); if(!arr.length)return '';
          return `<div><div class="text-[10px] font-black uppercase tracking-wider text-slate-500 mb-2">${sec.replace('SECTION-','Section ')} · ${arr.length}</div><div class="flex flex-wrap gap-2">${arr.map(x=>{const saved=x.is_saved===true||(x.is_saved!==false&&!!currentFinalBlueprintId);const dark={'SECTION-A':'bg-indigo-950 border-indigo-700 text-white','SECTION-B':'bg-amber-950 border-amber-700 text-white','SECTION-C':'bg-emerald-950 border-emerald-700 text-white','SECTION-D':'bg-rose-950 border-rose-700 text-white'};return `<button type="button" onclick="selectBlueprintSlot(${Number(x.slot_number)})" class="w-9 h-9 rounded-full border-2 text-xs font-black ${saved?(dark[x.section_type]||'bg-slate-950 border-slate-700 text-white'):(sectionStyles[x.section_type]||'')} ${Number(x.slot_number)===Number(activeSlotNumber)?'ring-4 ring-orange-300 scale-110':''}" aria-label="Edit question ${x.slot_number}">${Number(x.slot_number)}</button>`;}).join('')}</div></div>`;
        }).join('')}</div>
      </aside>
      <section class="rounded-2xl border-2 ${secStyle.split(' ')[0]} ${savedSectionBg} p-5 shadow-sm" id="slot-card-${Number(slot.slot_number)}">
        <div class="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4 mb-4">
          <div><div class="text-xs font-black uppercase tracking-wider text-slate-500">${escapeHtml(slot.section_type)}</div><h4 class="text-lg font-black ${isSlotSaved?'text-white':'text-slate-900'}">Question Slot #${Number(slot.slot_number)}</h4><p class="text-xs ${isSlotSaved?'text-slate-300':'text-slate-500'}">${isSlotSaved?'Saved slot · edit and save again to update':'Edit the requirements for this question slot.'}</p></div>
          <span class="rounded-full px-3 py-1 text-xs font-black ${secStyle}">${Number(slot.marks||1)} Mark(s) · ${matched} matching draft questions</span>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <label class="text-xs font-bold text-slate-600">Unit<select onchange="updateSlotUnit(${Number(slot.slot_number)},this.value)" class="mt-1 w-full rounded-xl border-slate-300 bg-slate-50 p-3 text-sm">${unitOptions}</select></label>
          <label class="text-xs font-bold text-slate-600">Sub-unit<select onchange="updateSlotSubUnit(${Number(slot.slot_number)},this.value)" class="mt-1 w-full rounded-xl border-slate-300 bg-slate-50 p-3 text-sm">${subOptions}</select></label>
          <label class="text-xs font-bold text-slate-600 sm:col-span-2">Question Type<select onchange="updateSlotField(${Number(slot.slot_number)},'question_type',this.value)" class="mt-1 w-full rounded-xl border-slate-300 bg-slate-50 p-3 text-sm">
            ${[['MCQ','Multiple Choice (MCQ)'],['FILL_BLANKS','Fill in the Blanks'],['TRUE_FALSE','True / False'],['MATCH','Match the Following'],['ASSERTION_REASON','Assertion & Reason'],['VSA','Very Short Answer (VSA)'],['PARAGRAPH','Paragraph Answer (5M)'],['ESSAY','Descriptive Essay (10M)'],['CASE_STUDY','Compulsory Case/Essay (10M)']].map(([v,l])=>`<option value="${v}" ${slot.question_type===v?'selected':''}>${l}</option>`).join('')}
          </select></label>
          <div class="rounded-xl border border-indigo-100 bg-indigo-50 p-3"><div class="text-[10px] font-black uppercase text-indigo-500">K-Level · Dean rule</div><div class="font-black text-indigo-900">${escapeHtml(slot.k_level || 'Resolving…')}</div></div>
          <div class="rounded-xl border border-indigo-100 bg-indigo-50 p-3"><div class="text-[10px] font-black uppercase text-indigo-500">CO-Level · Dean rule</div><div class="font-black text-indigo-900">${escapeHtml(slot.co_level || 'Resolving…')}</div></div>
          <div class="text-xs font-bold text-slate-600"><label>Marks · Dean template</label><div class="mt-1 rounded-xl border border-slate-200 bg-slate-100 p-3 text-sm font-black text-slate-800">${Number(slot.marks)} mark(s) · fixed</div><div class="flex items-center gap-2 mt-2"><button type="button" onclick="saveFinalBlueprintSlots()" class="shrink-0 px-3 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black shadow-sm"><i data-lucide="save" class="inline w-3.5 h-3.5 mr-1"></i>Save Slot</button></div></div>
        </div>
        ${slotRuleError ? `<div class="mt-3 rounded-xl border border-rose-200 bg-rose-50 p-3 text-xs font-bold text-rose-700">${escapeHtml(slotRuleError)}</div>` : ''}
        ${slot.remark_text ? `<div class="mt-3 rounded-xl border border-rose-300 bg-rose-50 p-3 text-xs font-bold text-rose-800"><i data-lucide="message-square-warning" class="inline w-4 h-4 mr-1"></i> Reviewer remark: ${escapeHtml(slot.remark_text)}</div>` : ''}
        <div class="mt-4 rounded-xl bg-slate-50 border border-slate-200 p-3 text-xs text-slate-600">${matched>0?`<strong class="text-emerald-700">${matched} matching question(s)</strong> currently exist in this unit, sub-unit and marks combination.`:'No exact matching questions are currently in the draft pool.'}</div>
      </section>
    </div>`;
  lucide.createIcons();
}

// Save Master Blueprint & Final Blueprint Slots
async function saveFinalBlueprintSlots() {
  if (!currentSlotsData.length || !currentDeanTemplateId) return Swal.fire({icon:'warning',title:'Dean template required',text:'Select a published Dean template before saving the final blueprint.'});
  if (slotRuleError || !slotRuleCount || currentSlotsData.length!==slotRuleCount || currentSlotsData.some(s => !s.k_level || !s.co_level)) {
    return Swal.fire({icon:'error',title:'Dean rules required',text:slotRuleError || 'K-Level and CO-Level rules must be resolved before saving.'});
  }

  const payload = {
    action: 'save_slots',
    dean_template_id: currentDeanTemplateId,
    dean_template_name: currentDeanTemplateName,
    csrf: <?=json_encode($_SESSION['qps_review_csrf'])?>,
    paper_code: currentCourseCode,
    semester: document.getElementById('fieldSemester')?.value || '',
    academic_year: document.getElementById('fieldAcademicYear')?.value || '',
    programme_year: document.getElementById('fieldProgrammeYear')?.value || '',
    programme_level: document.getElementById('fieldProgrammeYear')?.value || '',
    language: document.getElementById('fieldQuestionLanguage')?.value || 'EN',
    total_marks: Number(document.getElementById('fieldTotalMarks')?.value || 0),
    slots: currentSlotsData
  };

  try {
    const res = await fetch('<?php echo getBaseUrl(); ?>/api/save_final_blueprint_slots.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();

    if (data.success) {
      currentFinalBlueprintId = Number(data.final_blueprint_id || data.blueprint_id || data.blueprint?.id || 0);
      if (!currentFinalBlueprintId) throw new Error('Blueprint was saved, but the server did not return its ID. Reload the slot allocation before submitting.');
      currentSlotsData = currentSlotsData.map(slot => ({...slot, is_saved:true}));
      renderSlotAllocationTable();
      Swal.fire({
        icon: 'success',
        title: 'Final Blueprint Saved',
        text: data.message,
        confirmButtonColor: '#4f46e5'
      });
      loadCourseData(currentCourseCode);
    } else {
      throw new Error(data.message || 'Failed to save blueprint slots');
    }
  } catch (err) {
    Swal.fire({ icon: 'error', title: 'Save Failed', text: err.message });
  }
}

// Update Subunit dropdown based on selected Unit
function updateSubunitOptions() {
  const u = document.getElementById('fieldUnit').value;
  const suSel = document.getElementById('fieldSubUnit');
  suSel.innerHTML = `
    <option value="${u}.1">${u}.1</option>
    <option value="${u}.2">${u}.2</option>
    <option value="${u}.3">${u}.3</option>
    <option value="${u}.4">${u}.4</option>
    <option value="${u}.5">${u}.5</option>
    <option value="${u}.6">${u}.6</option>
  `;
  updateSelectedUnitQuestionCounts();
}

function syncCustomSubUnit() { updateSelectedUnitQuestionCounts(); }
function updateSelectedUnitQuestionCounts() {
  const unit = Number(document.getElementById('fieldUnit')?.value || 0);
  const sub = String(document.getElementById('fieldSubUnit')?.value || '');
  const unitCount = (Array.isArray(currentQuestions)?currentQuestions:[]).filter(q=>Number(q.unit_no)===unit).length;
  const subCount = (Array.isArray(currentQuestions)?currentQuestions:[]).filter(q=>Number(q.unit_no)===unit && String(q.sub_unit||'').trim()===sub).length;
  const uEl=document.getElementById('unitQuestionCount'), sEl=document.getElementById('subUnitQuestionCount');
  if(uEl)uEl.textContent=`${unitCount} question(s) entered in Unit ${unit}`;
  if(sEl)sEl.textContent=`${subCount} question(s) entered in Sub-unit ${sub}`;
}
function syncAnswerKeyField() {
  const qType=document.getElementById('fieldType')?.value||'';
  const field=document.getElementById('fieldAnswerKey');
  if(!field)return;
  if(qType==='MCQ') field.value=document.querySelector('input[name="mcqCorrect"]:checked')?.value||'';
  else if(qType==='MATCH') field.value=getMatchAnswerKey();
  else field.value='';
}

// Dynamic Marks & Section & Question Type Automation
function handleMarksChange() {
  const m = parseInt(document.getElementById('fieldMarks').value, 10);
  const section = document.getElementById('fieldSectionType').value;
  const typeSel = document.getElementById('fieldType');
  const kSel = document.getElementById('fieldKLevel');
  const secDCont = document.getElementById('sectionDCheckboxContainer');

  typeSel.innerHTML = '';
  secDCont.classList.add('hidden');

  // Populate question types based on both marks and section
  if (m === 1) {
    if (section === 'SECTION-A') {
      typeSel.innerHTML = `
        <option value="MCQ">Multiple Choice Question (MCQ)</option>
        <option value="MATCH">Match the Following</option>
        <option value="ASSERTION_REASON">Assertion & Reason</option>
        <option value="VSA">Very Short Answer (VSA)</option>
      `;
    } else {
      typeSel.innerHTML = `
        <option value="VSA">Very Short Answer (VSA)</option>
      `;
    }
    kSel.value = 'K1';
  } else if (m === 5) {
    if (section === 'SECTION-B') {
      typeSel.innerHTML = `
        <option value="PARAGRAPH">Paragraph / Either-Or Pair Question</option>
      `;
    } else {
      typeSel.innerHTML = `
        <option value="PARAGRAPH">Paragraph / Either-Or Pair Question</option>
      `;
    }
    kSel.value = 'K3';
  } else if (m === 10) {
    if (section === 'SECTION-C') {
      typeSel.innerHTML = `
        <option value="ESSAY">Essay / Descriptive Question</option>
      `;
    } else if (section === 'SECTION-D') {
      typeSel.innerHTML = `
        <option value="CASE_STUDY">Compulsory Case Study / Essay</option>
      `;
      secDCont.classList.remove('hidden');
    } else {
      typeSel.innerHTML = `
        <option value="ESSAY">Essay / Descriptive Question</option>
      `;
    }
    kSel.value = 'K5';
  }

  handleTypeChange();
}

function handleSectionChange() {
  // Re-run marks change logic to update question types based on section
  handleMarksChange();
}

function handleTypeChange() {
  const type = document.getElementById('fieldType').value;
  document.getElementById('containerMCQ').classList.add('hidden');
  document.getElementById('containerMatch').classList.add('hidden');
  document.getElementById('containerAR').classList.add('hidden');

  if (type === 'MCQ') {
    document.getElementById('containerMCQ').classList.remove('hidden');
  } else if (type === 'MATCH') {
    document.getElementById('containerMatch').classList.remove('hidden');
  } else if (type === 'ASSERTION_REASON') {
    document.getElementById('containerAR').classList.remove('hidden');
  }
  syncAnswerKeyField();
}

// Math LaTeX Formula Helpers
function insertLatex(code) {
  const ta = document.getElementById('fieldQuestionText');
  const start = ta.selectionStart;
  const end = ta.selectionEnd;
  const text = ta.value;
  ta.value = text.substring(0, start) + code + text.substring(end);
  ta.focus();
  ta.selectionEnd = start + code.length;
  renderMathPreview();
}

function applyQuestionLanguage() {
  const language = document.getElementById('fieldQuestionLanguage')?.value || 'EN';
  const textarea = document.getElementById('fieldQuestionText');
  const preview = document.getElementById('mathPreviewContent');
  const fonts = {
    TL: '"Noto Sans Tamil", "Latha", "Tamil MN", sans-serif',
    HI: '"Noto Sans Devanagari", "Mangal", sans-serif',
    EN: 'Arial, sans-serif',
    FR: 'Arial, sans-serif'
  };
  const langTags = {TL:'ta', HI:'hi', EN:'en', FR:'fr'};
  if (textarea) {
    textarea.lang = langTags[language] || 'en';
    textarea.style.fontFamily = fonts[language] || fonts.EN;
    textarea.style.fontSize = '15px';
  }
  if (preview) {
    preview.lang = langTags[language] || 'en';
    preview.style.fontFamily = fonts[language] || fonts.EN;
    preview.style.whiteSpace = 'pre-wrap';
  }
  renderMathPreview();
}

function renderMathPreview() {
  const text = document.getElementById('fieldQuestionText').value;
  const box = document.getElementById('mathPreviewBox');
  const content = document.getElementById('mathPreviewContent');

  if (!text.trim()) {
    box.classList.add('hidden');
    return;
  }

  box.classList.remove('hidden');
  content.innerText = text;
  const language = document.getElementById('fieldQuestionLanguage')?.value || 'EN';
  content.lang = ({TL:'ta', HI:'hi', EN:'en', FR:'fr'})[language] || 'en';
  content.style.whiteSpace = 'pre-wrap';
  content.style.fontFamily = language === 'TL' ? '"Noto Sans Tamil", "Latha", "Tamil MN", sans-serif' : (language === 'HI' ? '"Noto Sans Devanagari", "Mangal", sans-serif' : 'Arial, sans-serif');

  if (window.MathJax && window.MathJax.typesetPromise) {
    MathJax.typesetPromise([content]).catch(err => console.log(err));
  }
}

// Diagram Upload
async function uploadDiagramFile(input) {
  if (!input.files || !input.files[0]) return;
  const file = input.files[0];
  const formData = new FormData();
  formData.append('diagram_file', file);

  try {
    const res = await fetch('<?php echo getBaseUrl(); ?>/api/upload_diagram.php', {
      method: 'POST',
      body: formData
    });
    const data = await res.json();
    if (data.success) {
      document.getElementById('fieldImageUrl').value = data.url;
      document.getElementById('diagramPreviewImg').src = data.url;
      document.getElementById('diagramPreviewContainer').classList.remove('hidden');
      Swal.fire({ icon: 'success', title: 'Diagram Uploaded', text: 'Diagram attached successfully.', timer: 1500, showConfirmButton: false });
    } else {
      throw new Error(data.message || 'Upload failed');
    }
  } catch (err) {
    Swal.fire({ icon: 'error', title: 'Upload Failed', text: err.message });
  }
}

function removeDiagram() {
  document.getElementById('fieldImageUrl').value = '';
  document.getElementById('diagramPreviewContainer').classList.add('hidden');
  document.getElementById('diagramFileInput').value = '';
}

// Fetch Course Data & Blueprint
let slotRuleError = '';
let slotRuleCount = 0;
function setSlotRuleStatus(message, ok=false) {
  const el=document.getElementById('slotRuleStatus'); if(!el)return;
  el.textContent=message;el.className='rounded-full px-3 py-1 text-xs font-bold '+(ok?'bg-emerald-100 text-emerald-700':'bg-rose-100 text-rose-700');
  const save=document.getElementById('saveFinalBlueprintSlotsBtn');if(save)save.disabled=!ok;
  const saveNear=document.getElementById('saveFinalBlueprintSlotsNearMarks');if(saveNear)saveNear.disabled=!ok;
}
function syncSlotRuleContext() {
  const year=document.getElementById('fieldAcademicYear')?.value||currentDraft?.academic_year||'';
  const prog=document.getElementById('fieldProgrammeYear')?.value||'';
  const semester=document.getElementById('fieldSemester')?.value||currentDraft?.semester||'Semester 1';
  const yearEl=document.getElementById('fieldAcademicYear'),progEl=document.getElementById('fieldProgrammeYear'),semEl=document.getElementById('fieldSemester'),markEl=document.getElementById('fieldTotalMarks');
  if(yearEl){if(year&&!Array.from(yearEl.options).some(o=>o.value===year))yearEl.add(new Option(year,year));yearEl.value=year;}
  if(progEl&&prog)progEl.value=prog;
  if(semEl)semEl.value=semester;
  // Total Marks is selected by teaching staff. The selected Dean rule context,
  // not courses.maxmark, is authoritative for rule lookup and final allotment.
  if(markEl){
    markEl.disabled=false;
    Array.from(markEl.options).forEach(o=>{o.disabled=false;});
  }
  if(yearEl)yearEl.disabled=false;
  // Year of Programme is explicitly selected by teaching staff; course catalog
  // labels such as UG/PG or legacy programme values must not lock this selector.
  if(progEl)progEl.disabled=false;
}
function qpsProgrammeValue(value){const v=String(value||'').trim().toUpperCase();return ({'UG':'1st UG','PG':'1st PG'})[v]||String(value||'');}
async function resolveSlotRules() {
  if (!currentCourseCode) return;
  syncSlotRuleContext();
  const selectedMarks = Number(document.getElementById('fieldTotalMarks')?.value || 0);
  if (!currentDeanTemplateId || !currentSlotsData.length) {
    slotRuleCount = 0;
    slotRuleError = 'Select a published Dean template matching the selected academic context.';
    setSlotRuleStatus(slotRuleError, false);
    renderSlotAllocationTable();
    return;
  }
  if (!currentDraft) {
    slotRuleCount = 0;
    slotRuleError = 'Save the course context before validating K-Level and CO-Level rules.';
    setSlotRuleStatus(slotRuleError, false);
    renderSlotAllocationTable();
    return;
  }
  const context = {
    paper_code: currentCourseCode,
    semester: document.getElementById('fieldSemester')?.value || '',
    academic_year: document.getElementById('fieldAcademicYear')?.value || '',
    programme_year: document.getElementById('fieldProgrammeYear')?.value || '',
    programme_level: document.getElementById('fieldProgrammeYear')?.value || '',
    total_marks: selectedMarks,
    language: document.getElementById('fieldQuestionLanguage')?.value || 'EN'
  };
  try {
    const response = await fetch('<?php echo getBaseUrl(); ?>/api/question_rules.php', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({action:'resolve', csrf:<?=json_encode($_SESSION['qps_review_csrf'])?>, ...context})
    });
    const result = await response.json();
    if (!result.success) throw new Error(result.message || 'Dean question rules are not configured.');
    const rules = result.rules || {};
    slotRuleCount = Number(result.count || Object.keys(rules).length);
    if (currentSlotsData.length !== slotRuleCount) {
      throw new Error(`Selected Dean template contains ${currentSlotsData.length} slots, but the matching question_rules set contains ${slotRuleCount} question numbers. The template and Dean rules must have the same question count.`);
    }
    const mismatches = [];
    currentSlotsData = currentSlotsData.map(slot => {
      const rule = rules[String(slot.slot_number)];
      if (!rule) {
        mismatches.push(`Q${slot.slot_number}: no matching question rule exists.`);
        return {...slot, k_level:'', co_level:''};
      }
      const templateK = String(slot.k_level || '').trim().toUpperCase();
      const templateCO = String(slot.co_level || '').trim().toUpperCase();
      const ruleK = String(rule.k_level || '').trim().toUpperCase();
      const ruleCO = String(rule.co_level || '').trim().toUpperCase();
      if (templateK !== ruleK) mismatches.push(`Q${slot.slot_number}: template K-Level ${templateK || '(blank)'} does not match question rule ${ruleK}.`);
      if (templateCO !== ruleCO) mismatches.push(`Q${slot.slot_number}: template CO-Level ${templateCO || '(blank)'} does not match question rule ${ruleCO}.`);
      return {...slot, k_level:templateK, co_level:templateCO, rule_k_level:ruleK, rule_co_level:ruleCO};
    });
    const sum = currentSlotsData.reduce((n, slot) => n + Number(slot.marks || 0), 0);
    if (sum !== selectedMarks) mismatches.push(`Dean template slot marks total ${sum}; selected Total Marks is ${selectedMarks}.`);
    if (mismatches.length) throw new Error(mismatches.join('\n'));
    try {
      const rr = await fetch('<?php echo getBaseUrl(); ?>/api/remarks.php', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action:'list', csrf:<?=json_encode($_SESSION['qps_review_csrf'])?>, paper_code:currentCourseCode})});
      const rd = await rr.json();
      if (rd.success) {
        const by = {};
        (rd.remarks || []).filter(r => r.target_type === 'FINAL_SLOT').forEach(r => by[String(r.target_ref)] = r.remark_text);
        currentSlotsData = currentSlotsData.map(slot => ({...slot, remark_text:by[String(slot.slot_key)] || by['Q'+slot.slot_number] || ''}));
      }
    } catch (e) { console.warn('Unable to load final-slot remarks', e); }
    slotRuleError = '';
    setSlotRuleStatus(`Dean template verified: ${slotRuleCount} slots match question rules`, true);
  } catch (error) {
    slotRuleError = error.message || 'Unable to validate the selected Dean template.';
    slotRuleCount = 0;
    setSlotRuleStatus(slotRuleError, false);
  }
  renderSlotAllocationTable();
}

async function loadSavedFinalBlueprintSlotsForContext() {
  if (!currentCourseCode) return;
  const params = new URLSearchParams({
    action: 'load_slots',
    paper_code: currentCourseCode,
    semester: document.getElementById('fieldSemester')?.value || currentDraft?.semester || 'Semester 1',
    academic_year: document.getElementById('fieldAcademicYear')?.value || currentDraft?.academic_year || '',
    programme_year: document.getElementById('fieldProgrammeYear')?.value || currentDraft?.programme_year || '',
    total_marks: document.getElementById('fieldTotalMarks')?.value || '',
    language: document.getElementById('fieldQuestionLanguage')?.value || 'EN'
  });
  const response = await fetch(`<?php echo getBaseUrl(); ?>/api/save_final_blueprint_slots.php?${params.toString()}`);
  const result = await response.json();
  if (result.success && Array.isArray(result.slots) && result.slots.length) {
    currentSlotsData = result.slots;
    currentFinalBlueprintId = Number(result.blueprint?.id || 0);
  } else {
    currentFinalBlueprintId = 0;
  }
}

function deanYearCode(programmeValue) {
  const v = String(programmeValue || '').trim();
  const map = {'1st UG':'I','2nd UG':'II','3rd UG':'III','1st PG':'I','2nd PG':'II','I':'I','II':'II','III':'III','IV':'IV'};
  return map[v] || '';
}

function clearDeanTemplateState(message) {
  currentDeanTemplateId = 0;
  currentDeanTemplateName = '';
  currentSlotsData = [];
  currentFinalBlueprintId = 0;
  slotRuleCount = 0;
  slotRuleError = message || 'Select a published Dean template.';
  setSlotRuleStatus(slotRuleError, false);
  const status = document.getElementById('deanTemplateStatus');
  if (status) status.textContent = slotRuleError;
  renderSlotAllocationTable();
}

async function refreshDeanTemplates() {
  const seq = ++deanTemplateRequestSeq;
  const select = document.getElementById('deanTemplateSelect');
  if (!select) return;
  const academicYear = document.getElementById('fieldAcademicYear')?.value || '';
  const programme = document.getElementById('fieldProgrammeYear')?.value || '';
  const totalMarks = Number(document.getElementById('fieldTotalMarks')?.value || 0);
  const yearCode = deanYearCode(programme);
  if (!academicYear || !yearCode || !totalMarks) {
    select.innerHTML = '<option value="">Select Academic Year, Year of Programme and Total Marks first</option>';
    clearDeanTemplateState('Select Academic Year, Year of Programme and Total Marks to find a published Dean template.');
    return;
  }
  select.disabled = true;
  select.innerHTML = '<option value="">Loading matching Dean templates...</option>';
  try {
    const params = new URLSearchParams({action:'list', academic_year:academicYear, year_of_programme:yearCode, total_marks:String(totalMarks), csrf:<?=json_encode($_SESSION['qps_review_csrf'])?>});
    const response = await fetch(`<?php echo getBaseUrl(); ?>/api/teaching_dean_templates.php?${params.toString()}`, {cache:'no-store'});
    const result = await response.json();
    if (seq !== deanTemplateRequestSeq) return;
    if (!result.success) throw new Error(result.message || 'Unable to load Dean templates.');
    const templates = Array.isArray(result.data) ? result.data : [];
    if (!templates.length) {
      select.innerHTML = '<option value="">No matching published Dean template</option>';
      clearDeanTemplateState('No published Dean template matches this Academic Year, Year of Programme and Total Marks. Contact the Dean before proceeding.');
      return;
    }
    select.innerHTML = '<option value="">Choose a Dean template</option>' + templates.map(t => `<option value="${Number(t.id)}">${escapeHtml(t.template_name)} · ${Number(t.total_marks)} marks · ${Number(t.slot_count)} slots</option>`).join('');
    select.disabled = false;
    const status = document.getElementById('deanTemplateStatus');
    if (status) status.textContent = `${templates.length} published template(s) found for ${academicYear}, ${programme}, ${totalMarks} marks.`;
    clearDeanTemplateState('Choose one of the matching published Dean templates.');
  } catch (error) {
    if (seq !== deanTemplateRequestSeq) return;
    select.innerHTML = '<option value="">Unable to load Dean templates</option>';
    clearDeanTemplateState(error.message);
  } finally {
    if (seq === deanTemplateRequestSeq) select.disabled = false;
  }
}

async function loadSelectedDeanTemplate(templateId) {
  const id = Number(templateId || 0);
  if (!id) { clearDeanTemplateState('Choose a published Dean template.'); return; }
  try {
    const params = new URLSearchParams({action:'get', template_id:String(id), csrf:<?=json_encode($_SESSION['qps_review_csrf'])?>});
    const response = await fetch(`<?php echo getBaseUrl(); ?>/api/teaching_dean_templates.php?${params.toString()}`, {cache:'no-store'});
    const result = await response.json();
    if (!result.success) throw new Error(result.message || 'Unable to load selected template.');
    const template = result.data || {};
    const sections = Array.isArray(template.sections) ? template.sections : [];
    const slots = Array.isArray(template.slots) ? template.slots : [];
    const sectionMap = {};
    sections.forEach(section => {
      const raw = String(section.section_type || section.section_name || 'A').trim().toUpperCase();
      const code = raw.length === 1 ? raw : (raw.match(/[A-Z]$/)?.[0] || 'A');
      sectionMap[String(section.id)] = `SECTION-${code}`;
    });
    const ordered = slots.slice().sort((a,b) => Number(a.sort_order || 0) - Number(b.sort_order || 0) || Number(a.id || 0) - Number(b.id || 0));
    const used = new Set();
    currentSlotsData = ordered.map((slot, index) => {
      const label = String(slot.slot_label || '').trim();
      const match = label.match(/(?:Q|QUESTION\s*)?(\d+)/i);
      const number = match ? Number(match[1]) : index + 1;
      if (!Number.isInteger(number) || number < 1 || used.has(number)) throw new Error(`Template slot label "${label}" is missing a unique question number. Use Q1, Q2, Q3... in the Dean template.`);
      used.add(number);
      const sectionType = sectionMap[String(slot.section_id)] || 'SECTION-A';
      return {
        slot_key:`${sectionType}-Q${number}`, slot_number:number, section_type:sectionType,
        unit_no:Number(slot.unit_id || 0), sub_unit:'', question_type:'',
        k_level:String(slot.k_level || '').trim().toUpperCase(),
        co_level:String(slot.co_level || '').trim().toUpperCase(),
        marks:Number(slot.marks || 0), is_compulsory:true, choice_group:'',
        is_saved:false, dean_template_slot_id:Number(slot.id || 0)
      };
    });
    if (!currentSlotsData.length) throw new Error('The selected Dean template has no active question slots.');
    const selectedMarks = Number(document.getElementById('fieldTotalMarks')?.value || 0);
    const sum = currentSlotsData.reduce((n,s) => n + Number(s.marks || 0), 0);
    if (sum !== selectedMarks) throw new Error(`Template slots total ${sum} marks, but the selected paper total is ${selectedMarks}. Ask the Dean to correct the template.`);
    currentDeanTemplateId = Number(template.id || id);
    currentDeanTemplateName = String(template.template_name || template.name || 'Dean Template');
    currentFinalBlueprintId = 0;
    activeSlotNumber = currentSlotsData[0].slot_number;
    const status = document.getElementById('deanTemplateStatus');
    if (status) status.textContent = `Loaded: ${currentDeanTemplateName}. Assign Unit, Sub-unit and Question Type for each slot.`;
    await resolveSlotRules();
  } catch (error) {
    clearDeanTemplateState(error.message);
    Swal.fire({icon:'error', title:'Dean template could not be loaded', text:error.message});
  }
}

async function saveTeachingContext() {
  if (!currentCourseCode) return;
  const selectedMarks = Number(document.getElementById('fieldTotalMarks')?.value || 0);
  if (!selectedMarks) {
    await resolveSlotRules();
    return;
  }
  const payload = {
    action: 'save_context',
    csrf: <?=json_encode($_SESSION['qps_review_csrf'])?>,
    paper_code: currentCourseCode,
    academic_year: document.getElementById('fieldAcademicYear')?.value || '',
    programme_year: document.getElementById('fieldProgrammeYear')?.value || '',
    programme_level: document.getElementById('fieldProgrammeYear')?.value || '',
    semester: document.getElementById('fieldSemester')?.value || currentDraft?.semester || 'Semester 1',
    total_marks: selectedMarks,
    language: document.getElementById('fieldQuestionLanguage')?.value || 'EN'
  };
  try {
    const response = await fetch('<?php echo getBaseUrl(); ?>/api/save_draft_question.php', {
      method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!result.success) throw new Error(result.message || 'Unable to save academic details.');
    currentDraft = {...(currentDraft || {}), ...result.draft};
    await refreshDeanTemplates();
  } catch (error) {
    currentSlotsData = currentSlotsData.map(slot => ({...slot, k_level:'', co_level:''}));
    slotRuleCount = 0;
    slotRuleError = error.message || 'Unable to save the selected course context.';
    setSlotRuleStatus(slotRuleError, false);
    renderSlotAllocationTable();
    Swal.fire({icon:'error', title:'Academic Details Not Saved', text:slotRuleError});
  }
}

async function loadCourseData(courseCode) {
  if (!courseCode) return;
  coeApprovedQuestions = [];
  if (document.getElementById('allQuestionsCountBadge')) document.getElementById('allQuestionsCountBadge').textContent = currentQuestions.length;
  try {
    // document.getElementById('courseCodeBadge').innerText = courseCode;
    const res = await fetch(`<?php echo getBaseUrl(); ?>/api/get_draft_questions.php?paper_code=${encodeURIComponent(courseCode)}`);
    const data = await res.json();

    if (data.success) {
      currentDraft = data.draft;
      currentQuestions = data.questions || [];
      updateSelectedUnitQuestionCounts();
      if (!currentDraft) { syncSlotRuleContext(); await saveTeachingContext(); }
      if (currentDraft) {
        const yearSelect = document.getElementById('fieldAcademicYear');
        const programmeSelect = document.getElementById('fieldProgrammeYear');
        const savedYear = String(currentDraft.academic_year || '');
        const semesterSelect = document.getElementById('fieldSemester');
        const savedSemester = String(currentDraft.semester || '');
        if (semesterSelect && savedSemester && [...semesterSelect.options].some(o => o.value === savedSemester)) semesterSelect.value = savedSemester;
        const savedProgramme = String(currentDraft.programme_year || currentDraft.programme_level || currentDraft.degree_level || '');
        if (yearSelect && savedYear) {
          if (![...yearSelect.options].some(o => o.value === savedYear)) yearSelect.add(new Option(savedYear, savedYear));
          yearSelect.value = savedYear;
        }
        if (programmeSelect && savedProgramme) {
          const normalizedProgramme = ({'UG':'1st UG','PG':'1st PG'})[savedProgramme.toUpperCase()] || savedProgramme;
          if ([...programmeSelect.options].some(o => o.value === normalizedProgramme)) programmeSelect.value = normalizedProgramme;
        }
        const savedMarks = Number(currentDraft.total_marks || currentDraft.max_marks || 0);
        const totalMarksSelect = document.getElementById('fieldTotalMarks');
        if (totalMarksSelect && savedMarks > 0 && [...totalMarksSelect.options].some(o => Number(o.value) === savedMarks)) totalMarksSelect.value = String(savedMarks);
        const lastLanguage = String(currentDraft.language || (currentQuestions.length ? currentQuestions[currentQuestions.length - 1].language : 'EN')).toUpperCase();
        document.getElementById('fieldQuestionLanguage').value = ['EN','TL','HI','FR'].includes(lastLanguage) ? lastLanguage : 'EN';
        applyQuestionLanguage();
      }
      syncSlotRuleContext();
      if (document.getElementById('allQuestionsCountBadge')) document.getElementById('allQuestionsCountBadge').textContent = currentQuestions.length + coeApprovedQuestions.length;
      updateNextQuestionNumber();
      currentMatrix = data.blueprint_matrix || [];

      // Update Header Text & Status
      const sel = document.getElementById('courseSelect');
      const opt = sel.options[sel.selectedIndex];
      const title = opt ? opt.text.split(' - ')[1] || opt.text : courseCode;
      document.getElementById('courseTitleText').innerText = title;
      document.getElementById('blueprintHeaderTitle').innerText = `${courseCode} - ${title}`;

      const status = currentDraft ? currentDraft.status : 'DRAFT';
      document.getElementById('statusLabel').innerText = status;

      // Update Stats
      const sc = data.section_counts || {};
      document.getElementById('statTotalQ').innerText = sc.TOTAL_QUESTIONS || currentQuestions.length;
      document.getElementById('draftCountBadge').innerText = sc.TOTAL_QUESTIONS || currentQuestions.length;
      document.getElementById('statSecAMCQ').innerText = sc.A_MCQ || 0;
      document.getElementById('statSecAMatchAR').innerText = (sc.A_MATCH || 0) + (sc.A_AR || 0);
      document.getElementById('statSecAVSA').innerText = sc.A_VSA || 0;
      document.getElementById('statSecB').innerText = sc.B || 0;
      document.getElementById('statSecCD').innerText = (sc.C || 0) + (sc.D || 0);
      document.getElementById('statCorrections').innerText = sc.CORRECTIONS_COUNT || 0;
      document.getElementById('blueprintTotalMarks').innerText = sc.TOTAL_MARKS || 0;

      // Dean template is the only source of the slot structure. Never generate legacy defaults.
      clearDeanTemplateState('Select a published Dean template for this course context.');
      await refreshDeanTemplates();
      renderBlueprintMatrix();
      renderSlotAllocationTable();
      renderQuestionsList();
    }
  } catch (err) {
    console.error('Error loading course data:', err);
  }
}

// Keep numbering monotonic: deleting a middle question never renumbers the remaining questions.
function updateNextQuestionNumber() {
  const next = (Array.isArray(currentQuestions) ? currentQuestions.length : 0) + 1;
  const label = document.getElementById('nextQuestionNumber');
  if (label) label.innerText = `Next question number: ${next}`;
  const totalBadge = document.getElementById('totalQuestionCount');
  if (totalBadge) totalBadge.innerText = `Total Questions: ${Array.isArray(currentQuestions) ? currentQuestions.length : 0}`;
}

// Save or Update Question
let matchAItems = ['', '', '', ''];
let matchBItems = ['', '', '', '', ''];
let matchAssignments = ['', '', '', ''];
function renderMatchEditor(){
 const a=document.getElementById('matchColumnA'), b=document.getElementById('matchColumnB'), as=document.getElementById('matchAssignments');
 if(!a||!b||!as)return;
 a.innerHTML=matchAItems.map((v,i)=>`<div class="flex gap-2"><input class="match-a flex-1 min-w-0 px-3 py-2 border rounded-lg text-sm" value="${escapeHtml(v)}" placeholder="Row ${i+1}" oninput="matchAItems[${i}]=this.value"><button type="button" onclick="removeMatchRow(${i})" class="text-rose-600">×</button></div>`).join('');
 b.innerHTML=matchBItems.map((v,i)=>`<div class="flex gap-2"><input class="match-b flex-1 min-w-0 px-3 py-2 border rounded-lg text-sm" value="${escapeHtml(v)}" placeholder="Option ${i+1}" oninput="matchBItems[${i}]=this.value"><button type="button" onclick="removeMatchOption(${i})" class="text-rose-600">×</button></div>`).join('');
 as.innerHTML=matchAItems.map((v,i)=>{const usedByOthers=matchAssignments.map((value,row)=>row!==i?String(value):'').filter(Boolean);return `<label class="text-xs text-slate-600 flex items-center gap-2">Row ${i+1}<select class="border rounded-lg p-2 flex-1" onchange="setMatchAssignment(${i},this.value)"><option value="">Choose option</option>${matchBItems.map((x,j)=>{const optionNo=String(j+1);if(usedByOthers.includes(optionNo))return '';return `<option value="${optionNo}" ${String(matchAssignments[i]||'')===optionNo?'selected':''}>Option ${j+1}</option>`;}).join('')}</select></label>`;}).join('');
 document.getElementById('matchAnswerKeyPreview').textContent=getMatchAnswerKey()||'—'; syncAnswerKeyField();
}
function setMatchAssignment(row,value){matchAssignments[row]=value;renderMatchEditor();}
function addMatchRow(){matchAItems.push('');matchAssignments.push('');matchBItems.push('');renderMatchEditor();}
function addMatchOption(){matchBItems.push('');renderMatchEditor();}
function removeMatchRow(i){if(matchAItems.length<=1)return;matchAItems.splice(i,1);matchAssignments.splice(i,1);renderMatchEditor();}
function removeMatchOption(i){if(matchBItems.length<=matchAItems.length+1){Swal.fire('Keep one extra option','Column B must have at least one more option than Column A.','info');return;}matchBItems.splice(i,1);matchAssignments=matchAssignments.map(v=>v==i+1?'':(v>i+1?String(+v-1):v));renderMatchEditor();}
function getMatchColumnA(){return matchAItems.slice();}
function getMatchColumnB(){return matchBItems.slice();}
function getMatchAnswerKey(){return matchAssignments.join(',');}
function escapeHtml(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
document.addEventListener('DOMContentLoaded',()=>{renderMatchEditor();applyQuestionLanguage();updateSelectedUnitQuestionCounts();syncAnswerKeyField();});

async function handleSaveQuestion(e) {
  e.preventDefault();
  const selectedMarks = Number(document.getElementById('fieldTotalMarks')?.value || 0);
  if (!selectedMarks) {
    Swal.fire({icon:'warning',title:'Select Total Marks',text:'Choose Total Marks in Academic & Dean Rule Context before entering questions.'});
    return;
  }
  await saveTeachingContext();
  if (!currentDraft?.id) {
    Swal.fire({icon:'error',title:'Course Context Not Saved',text:slotRuleError || 'Save Academic Year, Year of Programme, Semester, Total Marks and Language first.'});
    return;
  }
  const editId = parseInt(document.getElementById('editQuestionId').value, 10);
  const unitNo = parseInt(document.getElementById('fieldUnit').value, 10);
  const subUnit = document.getElementById('fieldSubUnit').value;
  const marks = parseInt(document.getElementById('fieldMarks').value, 10);
  const qType = document.getElementById('fieldType').value;
  const kLevel = document.getElementById('fieldKLevel').value;
  const coLevel = document.getElementById('fieldCOLevel').value;
  const qText = document.getElementById('fieldQuestionText').value.trim();
  const isCompulsory = document.getElementById('fieldIsCompulsory').checked;
  let answerKey = qType === 'MATCH' ? getMatchAnswerKey() : document.getElementById('fieldAnswerKey').value.trim();
  const language = document.getElementById('fieldQuestionLanguage').value;
  const imageUrl = document.getElementById('fieldImageUrl').value;

  if (!qText) {
    Swal.fire({ icon: 'warning', title: 'Missing Question Text', text: 'Please enter the question statement.' });
    return;
  }

  let options = null;
  if (qType === 'MCQ') {
    const correctOpt = document.querySelector('input[name="mcqCorrect"]:checked')?.value || '';
    options = {
      A: document.getElementById('mcqOptA').value.trim(),
      B: document.getElementById('mcqOptB').value.trim(),
      C: document.getElementById('mcqOptC').value.trim(),
      D: document.getElementById('mcqOptD').value.trim(),
      correct: correctOpt
    };
    if (!options.A || !options.B || !options.C || !options.D || !correctOpt) { Swal.fire({icon:'warning',title:'Complete MCQ options',text:'Enter all four options and select the correct answer before saving.'}); return; }
    answerKey = correctOpt;
  }

  let matchColA = null, matchColB = null;
  if (qType === 'MATCH') {
    matchColA = getMatchColumnA();
    matchColB = getMatchColumnB();
    if (!matchColA.length || matchColA.some(v => !v) || matchColB.some(v => !v) || matchAssignments.some(v => !v) || new Set(matchAssignments).size !== matchAssignments.length) { Swal.fire({icon:'warning',title:'Complete matching pairs',text:'Enter every Column A/B item and assign an option to each row.'}); return; }
  }

  let assertionText = '', reasonText = '';
  if (qType === 'ASSERTION_REASON') {
    assertionText = document.getElementById('arAssertionText').value.trim();
    reasonText = document.getElementById('arReasonText').value.trim();
  }

  const sectionType = document.getElementById('fieldSectionType').value;

  const payload = {
    csrf: <?=json_encode($_SESSION['qps_review_csrf'])?>,
    action: 'save_question',
    question_id: editId,
    paper_code: currentCourseCode,
    semester: document.getElementById('fieldSemester')?.value || currentDraft?.semester || 'Semester 1',
    academic_year: document.getElementById('fieldAcademicYear')?.value || currentDraft?.academic_year || '',
    programme_year: document.getElementById('fieldProgrammeYear')?.value || currentDraft?.programme_year || '',
    programme_level: document.getElementById('fieldProgrammeYear')?.value || currentDraft?.programme_level || currentDraft?.degree_level || '',
    total_marks: Number(document.getElementById('fieldTotalMarks')?.value || currentDraft?.total_marks || 0),
    unit_no: unitNo,
    sub_unit: subUnit,
    marks: marks,
    question_type: qType,
    section_type: sectionType,
    k_level: kLevel,
    co_level: coLevel,
    question_text: qText,
    is_compulsory: isCompulsory ? 1 : 0,
    options: options,
    match_column_a: matchColA,
    match_column_b: matchColB,
    assertion_text: assertionText,
    reason_text: reasonText,
    answer_key: answerKey,
    language: language,
    image_url: imageUrl
  };

  try {
    const res = await fetch('<?php echo getBaseUrl(); ?>/api/save_draft_question.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();

    if (data.success) {
      Swal.fire({
        icon: 'success',
        title: editId > 0 ? 'Question Updated' : 'Question Added to Draft',
        text: data.message,
        timer: 1500,
        showConfirmButton: false
      });
      resetQuestionForm();
      loadCourseData(currentCourseCode);
    } else {
      throw new Error(data.message || 'Failed to save question');
    }
  } catch (err) {
    Swal.fire({ icon: 'error', title: 'Error Saving Question', text: err.message });
  }
}

// Reset Question Form. Dynamic MATCH fields are rendered from arrays, so do not
// address the old static matchA1/matchB1 elements (they no longer exist).
function resetQuestionForm() {
  const setValue = (id, value = '') => {
    const el = document.getElementById(id);
    if (el) el.value = value;
  };
  const setText = (id, value) => {
    const el = document.getElementById(id);
    if (el) el.innerText = value;
  };
  const setHtml = (id, value) => {
    const el = document.getElementById(id);
    if (el) el.innerHTML = value;
  };
  const setChecked = (id, value = false) => {
    const el = document.getElementById(id);
    if (el) el.checked = value;
  };

  setValue('editQuestionId', '0');
  setText('formModeTitle', 'Add New Question');
  updateNextQuestionNumber();
  setText('formModeIcon', '+');
  setHtml('btnSaveQuestion', '<i data-lucide="save" class="w-4 h-4"></i> Save Question to Bank Draft');
  setValue('fieldQuestionText');
  setValue('fieldAnswerKey');
  const correctionBanner = document.getElementById('correctionAlertBanner');
  if (correctionBanner) correctionBanner.classList.add('hidden');
  setChecked('fieldIsCompulsory', false);
  setValue('fieldSectionType', 'SECTION-A');

  ['mcqOptA','mcqOptB','mcqOptC','mcqOptD','arAssertionText','arReasonText'].forEach(id => setValue(id));
  document.querySelectorAll('input[name="mcqCorrect"]').forEach(el => { el.checked = el.value === 'A'; });
  syncAnswerKeyField();
  updateSelectedUnitQuestionCounts();

  // Restore the initial four A rows and five B options (one distractor).
  matchAItems = ['', '', '', ''];
  matchBItems = ['', '', '', '', ''];
  matchAssignments = ['', '', '', ''];
  renderMatchEditor();

  removeDiagram();
  renderMathPreview();
  if (window.lucide) lucide.createIcons();
}

// Edit Question - Load into form
function editQuestion(qId) {
  const q = currentQuestions.find(item => parseInt(item.id, 10) === parseInt(qId, 10));
  if (!q) return;

  switchTab('entry');

  document.getElementById('editQuestionId').value = q.id;
  document.getElementById('formModeTitle').innerText = `Edit Question #${q.q_number || q.id}`;
  document.getElementById('formModeIcon').innerText = '✏️';
  document.getElementById('btnSaveQuestion').innerHTML = '<i data-lucide="check" class="w-4 h-4"></i> Update Question in Draft';

  document.getElementById('fieldUnit').value = q.unit_no;
  updateSubunitOptions();
  document.getElementById('fieldSubUnit').value = q.sub_unit;
  document.getElementById('fieldMarks').value = q.marks;
  document.getElementById('fieldSectionType').value = q.section_type || 'SECTION-A';
  handleMarksChange();
  document.getElementById('fieldType').value = q.question_type;
  handleTypeChange();

  document.getElementById('fieldKLevel').value = q.k_level;
  document.getElementById('fieldCOLevel').value = q.co_level;
  document.getElementById('fieldQuestionText').value = q.question_text;
  document.getElementById('fieldQuestionLanguage').value = (q.language || 'EN').toUpperCase();
  if (q.question_type === 'MATCH') {
    try { matchAItems = Array.isArray(q.match_column_a) ? q.match_column_a : JSON.parse(q.match_column_a || '[]'); } catch(e) { matchAItems=['','','','']; }
    try { matchBItems = Array.isArray(q.match_column_b) ? q.match_column_b : JSON.parse(q.match_column_b || '[]'); } catch(e) { matchBItems=['','','','','']; }
    matchAssignments = String(q.answer_key || '').split(',').map(v=>v.trim());
    while(matchAssignments.length<matchAItems.length)matchAssignments.push('');
    renderMatchEditor();
  }
  document.getElementById('fieldAnswerKey').value = q.answer_key || '';
  syncAnswerKeyField();
  updateSelectedUnitQuestionCounts();

  if (q.section_type === 'SECTION-D') {
    document.getElementById('fieldIsCompulsory').checked = true;
  }

  // Load MCQ Options
  if (q.options) {
    document.getElementById('mcqOptA').value = q.options.A || '';
    document.getElementById('mcqOptB').value = q.options.B || '';
    document.getElementById('mcqOptC').value = q.options.C || '';
    document.getElementById('mcqOptD').value = q.options.D || '';
    if (q.options.correct) {
      const radio = document.querySelector(`input[name="mcqCorrect"][value="${q.options.correct}"]`);
      if (radio) radio.checked = true;
    }
    syncAnswerKeyField();
  }

  // Load AR
  document.getElementById('arAssertionText').value = q.assertion_text || '';
  document.getElementById('arReasonText').value = q.reason_text || '';

  // Load Diagram
  if (q.image_url) {
    document.getElementById('fieldImageUrl').value = q.image_url;
    document.getElementById('diagramPreviewImg').src = q.image_url;
    document.getElementById('diagramPreviewContainer').classList.remove('hidden');
  } else {
    removeDiagram();
  }

  // Correction Alert Banner
  if (q.correction_status === 'NEEDS_CORRECTION' && q.remarks) {
    document.getElementById('correctionAlertText').innerText = q.remarks;
    document.getElementById('correctionAlertBanner').classList.remove('hidden');
  } else {
    document.getElementById('correctionAlertBanner').classList.add('hidden');
  }

  renderMathPreview();
  lucide.createIcons();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Delete Question
async function deleteQuestion(qId) {
  const result = await Swal.fire({
    title: 'Delete this question?',
    text: 'This will remove the question from the draft question bank.',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#e11d48',
    cancelButtonColor: '#64748b',
    confirmButtonText: 'Yes, Delete'
  });

  if (!result.isConfirmed) return;

  try {
    const res = await fetch('<?php echo getBaseUrl(); ?>/api/save_draft_question.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'delete_question', question_id: qId, csrf: <?=json_encode($_SESSION['qps_review_csrf'])?> })
    });
    const data = await res.json();
    if (data.success) {
      Swal.fire({ icon: 'success', title: 'Deleted', text: 'Question removed from draft.', timer: 1200, showConfirmButton: false });
      loadCourseData(currentCourseCode);
    } else {
      throw new Error(data.message || 'Delete failed');
    }
  } catch (err) {
    Swal.fire({ icon: 'error', title: 'Error', text: err.message });
  }
}

// Submit Question Bank to HOD
async function submitBankToHOD() {
  if (!currentQuestions.length) {
    Swal.fire({ icon: 'warning', title: 'Empty Bank Draft', text: 'Please enter at least one question before submitting to HOD.' });
    return;
  }

  const result = await Swal.fire({
    title: 'Submit Question Bank to HOD?',
    text: `You are submitting ${currentQuestions.length} questions for ${currentCourseCode} to the Head of Department for review and verification.`,
    icon: 'question',
    showCancelButton: true,
    confirmButtonColor: '#4f46e5',
    cancelButtonColor: '#64748b',
    confirmButtonText: 'Yes, Submit to HOD'
  });

  if (!result.isConfirmed) return;

  try {
    if (!currentDraft?.id) throw new Error('Save the question bank draft before submitting.');
    if (!currentFinalBlueprintId) throw new Error('Save the Final Question Paper Blueprint before submitting.');
    const res = await fetch('<?php echo getBaseUrl(); ?>/api/workflow.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'staff_submit',
        csrf: <?=json_encode($_SESSION['qps_review_csrf'])?>,
        bank_draft_id: Number(currentDraft.id),
        final_blueprint_id: Number(currentFinalBlueprintId)
      })
    });
    const data = await res.json();

    if (data.success) {
      Swal.fire({
        icon: 'success',
        title: 'Submitted to HOD!',
        text: data.message,
        confirmButtonColor: '#4f46e5'
      });
      loadCourseData(currentCourseCode);
    } else {
      throw new Error(data.message || 'Submission failed');
    }
  } catch (err) {
    Swal.fire({ icon: 'error', title: 'Submission Failed', text: err.message });
  }
}

// Render Blueprint Matrix Table matching sample-blueprint.jpeg
function renderBlueprintMatrix() {
  const tbody = document.getElementById('blueprintMatrixBody');
  const tfoot = document.getElementById('blueprintMatrixFoot');
  if (!tbody) return;

  if (!currentMatrix || !currentMatrix.length) {
    tbody.innerHTML = `<tr><td colspan="16" class="p-8 text-center text-slate-400 font-medium">No entered questions yet. Enter questions in Tab 1 to dynamically compile the blueprint rows for your course.</td></tr>`;
    if (tfoot) tfoot.innerHTML = '';
    const badge = document.getElementById('blueprintTotalMarks');
    if (badge) badge.innerText = '0';
    return;
  }

  let grand = {
    mcq_k1: 0, mcq_k2: 0, mcq_tot: 0,
    vsa_k1: 0, vsa_k2: 0, vsa_tot: 0,
    sec_b_k3: 0, sec_b_k4: 0, sec_b_tot: 0,
    sec_c_k5: 0, sec_c_k6: 0, sec_c_tot: 0,
    sec_d_k6: 0, sec_d_tot: 0,
    total_q: 0, total_marks: 0
  };

  let rowsHtml = '';
  // Collect distinct units present in entered rows
  const presentUnits = [...new Set(currentMatrix.map(r => parseInt(r.unit, 10)))].sort((a,b) => a - b);

  presentUnits.forEach(u => {
    const unitRows = currentMatrix.filter(r => parseInt(r.unit, 10) === u);
    if (!unitRows.length) return;

    unitRows.forEach((row, idx) => {
      const mcqTot = (row.mcq_k1 || 0) + (row.mcq_k2 || 0);
      const vsaTot = (row.vsa_k1 || 0) + (row.vsa_k2 || 0);
      const bTot = (row.sec_b_k3 || 0) + (row.sec_b_k4 || 0);
      const cTot = (row.sec_c_k5 || 0) + (row.sec_c_k6 || 0);
      const dTot = row.sec_d_k6 || 0;
      const totQ = row.total_questions || 0;
      const totM = row.total_marks || 0;

      // Grand totals
      grand.mcq_k1 += row.mcq_k1 || 0; grand.mcq_k2 += row.mcq_k2 || 0; grand.mcq_tot += mcqTot;
      grand.vsa_k1 += row.vsa_k1 || 0; grand.vsa_k2 += row.vsa_k2 || 0; grand.vsa_tot += vsaTot;
      grand.sec_b_k3 += row.sec_b_k3 || 0; grand.sec_b_k4 += row.sec_b_k4 || 0; grand.sec_b_tot += bTot;
      grand.sec_c_k5 += row.sec_c_k5 || 0; grand.sec_c_k6 += row.sec_c_k6 || 0; grand.sec_c_tot += cTot;
      grand.sec_d_k6 += row.sec_d_k6 || 0; grand.sec_d_tot += dTot;
      grand.total_q += totQ; grand.total_marks += totM;

      const unitRoman = ['I', 'II', 'III', 'IV', 'V'][u - 1] || u;

      rowsHtml += `
        <tr class="hover:bg-slate-50 transition-colors ${idx === unitRows.length - 1 ? 'border-b-2 border-slate-300' : 'border-b border-slate-200'}">
          ${idx === 0 ? `<td rowspan="${unitRows.length}" class="p-2 border-r border-slate-300 font-bold bg-slate-100 text-slate-800 align-middle">Unit ${unitRoman}</td>` : ''}
          <td class="p-2 border-r border-slate-300 font-semibold text-slate-700 bg-slate-50/50">${row.sub_unit}</td>
          
          <!-- MC 1M -->
          <td class="p-2 border-r border-slate-200 font-mono ${row.mcq_k1 ? 'bg-blue-50 text-blue-800 font-bold' : 'text-slate-400'}">${row.mcq_k1 || 0}</td>
          <td class="p-2 border-r border-slate-200 font-mono ${row.mcq_k2 ? 'bg-blue-50 text-blue-800 font-bold' : 'text-slate-400'}">${row.mcq_k2 || 0}</td>
          <td class="p-2 border-r border-slate-300 font-mono bg-blue-100/50 font-bold text-blue-900">${mcqTot}</td>

          <!-- VSA 1M -->
          <td class="p-2 border-r border-slate-200 font-mono ${row.vsa_k1 ? 'bg-sky-50 text-sky-800 font-bold' : 'text-slate-400'}">${row.vsa_k1 || 0}</td>
          <td class="p-2 border-r border-slate-200 font-mono ${row.vsa_k2 ? 'bg-sky-50 text-sky-800 font-bold' : 'text-slate-400'}">${row.vsa_k2 || 0}</td>
          <td class="p-2 border-r border-slate-300 font-mono bg-sky-100/50 font-bold text-sky-900">${vsaTot}</td>

          <!-- Sec B 5M -->
          <td class="p-2 border-r border-slate-200 font-mono ${row.sec_b_k3 ? 'bg-amber-50 text-amber-800 font-bold' : 'text-slate-400'}">${row.sec_b_k3 || 0}</td>
          <td class="p-2 border-r border-slate-200 font-mono ${row.sec_b_k4 ? 'bg-amber-50 text-amber-800 font-bold' : 'text-slate-400'}">${row.sec_b_k4 || 0}</td>
          <td class="p-2 border-r border-slate-300 font-mono bg-amber-100/50 font-bold text-amber-900">${bTot}</td>

          <!-- Sec C 10M -->
          <td class="p-2 border-r border-slate-200 font-mono ${row.sec_c_k5 ? 'bg-emerald-50 text-emerald-800 font-bold' : 'text-slate-400'}">${row.sec_c_k5 || 0}</td>
          <td class="p-2 border-r border-slate-200 font-mono ${row.sec_c_k6 ? 'bg-emerald-50 text-emerald-800 font-bold' : 'text-slate-400'}">${row.sec_c_k6 || 0}</td>
          <td class="p-2 border-r border-slate-300 font-mono bg-emerald-100/50 font-bold text-emerald-900">${cTot}</td>

          <!-- Sec D 10M -->
          <td class="p-2 border-r border-slate-200 font-mono ${row.sec_d_k6 ? 'bg-purple-50 text-purple-800 font-bold' : 'text-slate-400'}">${row.sec_d_k6 || 0}</td>
          <td class="p-2 border-r border-slate-300 font-mono bg-purple-100/50 font-bold text-purple-900">${dTot}</td>

          <!-- Totals -->
          <td class="p-2 border-r border-slate-300 font-mono font-bold bg-slate-100 text-slate-800">${totQ}</td>
          <td class="p-2 font-mono font-extrabold bg-slate-100 text-indigo-900">${totM}M</td>
        </tr>
      `;
    });
  });

  tbody.innerHTML = rowsHtml;

  tfoot.innerHTML = `
    <tr>
      <td colspan="2" class="p-3 border-r border-slate-300 text-right uppercase tracking-wider font-extrabold text-slate-900 bg-slate-200">Total Available</td>
      <td class="p-2 border-r border-slate-300 font-mono text-blue-900 bg-blue-100">${grand.mcq_k1}</td>
      <td class="p-2 border-r border-slate-300 font-mono text-blue-900 bg-blue-100">${grand.mcq_k2}</td>
      <td class="p-2 border-r border-slate-300 font-mono text-blue-950 font-black bg-blue-200">${grand.mcq_tot}</td>

      <td class="p-2 border-r border-slate-300 font-mono text-sky-900 bg-sky-100">${grand.vsa_k1}</td>
      <td class="p-2 border-r border-slate-300 font-mono text-sky-900 bg-sky-100">${grand.vsa_k2}</td>
      <td class="p-2 border-r border-slate-300 font-mono text-sky-950 font-black bg-sky-200">${grand.vsa_tot}</td>

      <td class="p-2 border-r border-slate-300 font-mono text-amber-900 bg-amber-100">${grand.sec_b_k3}</td>
      <td class="p-2 border-r border-slate-300 font-mono text-amber-900 bg-amber-100">${grand.sec_b_k4}</td>
      <td class="p-2 border-r border-slate-300 font-mono text-amber-950 font-black bg-amber-200">${grand.sec_b_tot}</td>

      <td class="p-2 border-r border-slate-300 font-mono text-emerald-900 bg-emerald-100">${grand.sec_c_k5}</td>
      <td class="p-2 border-r border-slate-300 font-mono text-emerald-900 bg-emerald-100">${grand.sec_c_k6}</td>
      <td class="p-2 border-r border-slate-300 font-mono text-emerald-950 font-black bg-emerald-200">${grand.sec_c_tot}</td>

      <td class="p-2 border-r border-slate-300 font-mono text-purple-900 bg-purple-100">${grand.sec_d_k6}</td>
      <td class="p-2 border-r border-slate-300 font-mono text-purple-950 font-black bg-purple-200">${grand.sec_d_tot}</td>

      <td class="p-2 border-r border-slate-300 font-mono font-black text-slate-900 bg-slate-300 text-sm">${grand.total_q}</td>
      <td class="p-2 font-mono font-black text-indigo-950 bg-indigo-200 text-sm">${grand.total_marks}M</td>
    </tr>
  `;
}

// Draft pool table with a clear indicator and preview for questions with attached images.
function renderQuestionsList() {
  const container = document.getElementById('draftQuestionsList');
  if (!container) return;
  const filterSec = document.getElementById('filterSection')?.value || 'ALL';
  const filterCorr = document.getElementById('filterCorrection')?.value || 'ALL';
  const filtered = (Array.isArray(currentQuestions) ? currentQuestions : []).filter(q => {
    if (filterSec !== 'ALL' && q.section_type !== filterSec) return false;
    if (filterCorr === 'NEEDS_CORRECTION' && q.correction_status !== 'NEEDS_CORRECTION') return false;
    if (filterCorr === 'CLEAN' && q.correction_status === 'NEEDS_CORRECTION') return false;
    return true;
  });
  if (!filtered.length) {
    container.innerHTML = `<div class="p-8 text-center bg-slate-50 rounded-xl border border-dashed border-slate-200"><i data-lucide="inbox" class="w-10 h-10 text-slate-400 mx-auto mb-2"></i><h4 class="text-sm font-bold text-slate-700">No Draft Questions Found</h4><p class="text-xs text-slate-500 mt-1">Use the Question Entry Form tab to create your first question.</p></div>`;
    if (window.lucide) lucide.createIcons();
    return;
  }
  const byUnit = new Map();
  filtered.forEach(q => {
    const unit = Math.max(1, Number(q.unit_no || 1));
    if (!byUnit.has(unit)) byUnit.set(unit, []);
    byUnit.get(unit).push(q);
  });
  const roman = n => ['I','II','III','IV','V'][Number(n)-1] || String(n);
  const sectionMeta = {
    'SECTION-A': {label:'Section A', cls:'bg-indigo-50 text-indigo-950 border-indigo-100'},
    'SECTION-B': {label:'Section B', cls:'bg-amber-50 text-amber-950 border-amber-100'},
    'SECTION-C': {label:'Section C', cls:'bg-emerald-50 text-emerald-950 border-emerald-100'},
    'SECTION-D': {label:'Section D', cls:'bg-rose-50 text-rose-950 border-rose-100'}
  };
  const groups = [...byUnit.entries()].sort((a,b)=>a[0]-b[0]).map(([unit, questions]) => {
    const bySection = new Map();
    questions.forEach(q => {
      const section = String(q.section_type || 'SECTION-A').toUpperCase();
      if (!bySection.has(section)) bySection.set(section, []);
      bySection.get(section).push(q);
    });
    const sectionHtml = ['SECTION-A','SECTION-B','SECTION-C','SECTION-D'].filter(sec=>bySection.has(sec)).map(section => {
      const sectionQuestions = bySection.get(section);
      const rows = sectionQuestions.map((q, idx) => {
        const imageUrl = String(q.image_url || q.diagram_url || q.image_path || '').trim();
        const hasImage = imageUrl !== '';
        const safeQuestion = escapeHtml(q.question_text || '');
        const isMatch = String(q.question_type || '').toUpperCase() === 'MATCH';
        const canPreview = hasImage || isMatch;
        const questionCell = canPreview
          ? `<button type="button" onclick="openQuestionImagePreview(${Number(q.id)})" class="group text-left w-full rounded-lg border ${hasImage ? 'border-sky-200 bg-sky-50 hover:bg-sky-100 hover:border-sky-400' : 'border-indigo-200 bg-indigo-50 hover:bg-indigo-100 hover:border-indigo-400'} px-3 py-2 transition"><span class="block text-slate-800 font-semibold">${safeQuestion}</span><span class="inline-flex flex-wrap items-center gap-1.5 mt-1 text-[11px] font-bold text-indigo-700">${hasImage ? 'Image attached · ' : ''}${isMatch ? 'Match details · ' : ''}Click to view</span></button>`
          : `<span class="text-slate-800">${safeQuestion}</span>`;
        return `<tr class="border-t border-slate-200 hover:bg-slate-50"><td class="p-3 whitespace-nowrap">${escapeHtml(q.q_number || idx + 1)}</td><td class="p-2 min-w-[260px]">${questionCell}</td><td class="p-3 text-center">${escapeHtml(q.question_type || '')}</td><td class="p-3 text-center whitespace-nowrap"><button type="button" onclick="editQuestion(${Number(q.id)})" class="px-2.5 py-1.5 rounded-lg bg-slate-100 text-slate-700 text-xs font-bold hover:bg-slate-200">Edit</button><button type="button" onclick="deleteQuestion(${Number(q.id)})" class="px-2.5 py-1.5 rounded-lg bg-rose-50 text-rose-700 text-xs font-bold ml-1 hover:bg-rose-100">Delete</button></td></tr>`;
      }).join('');
      const meta = sectionMeta[section] || {label:section.replace('SECTION-','Section '),cls:'bg-slate-50 text-slate-900 border-slate-200'};
      return `<section class="overflow-hidden rounded-lg border ${meta.cls}"><div class="flex items-center justify-between px-3 py-2 border-b"><strong class="text-xs font-black uppercase tracking-wide">${meta.label}</strong><span class="text-[10px] font-black">${sectionQuestions.length} question(s)</span></div><div class="overflow-x-auto bg-white"><table class="w-full text-sm"><thead class="bg-slate-50 text-slate-600"><tr><th class="p-3 text-left">Q.No</th><th class="p-3 text-left">Question</th><th class="p-3 text-center">Type</th><th class="p-3 text-center">Actions</th></tr></thead><tbody>${rows}</tbody></table></div></section>`;
    }).join('');
    return `<section class="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm"><div class="flex items-center justify-between gap-3 bg-slate-900 px-4 py-3 border-b border-slate-700"><div class="font-black text-white">Unit ${roman(unit)}</div><span class="rounded-full bg-white/10 border border-white/20 px-2.5 py-1 text-[11px] font-black text-white">${questions.length} question(s)</span></div><div class="p-3 space-y-3">${sectionHtml}</div></section>`;
  }).join('');
  container.innerHTML = `<div class="space-y-4">${groups}</div>`;
  if (window.lucide) lucide.createIcons();
}

let allQuestionsRequestToken = 0;
async function loadAllQuestions() {
  const token = ++allQuestionsRequestToken;
  const container = document.getElementById('allQuestionsList');
  if (container) container.innerHTML = '<div class="p-6 text-center text-sm text-slate-500">Loading all questions…</div>';
  try {
    const response = await fetch(`<?php echo getBaseUrl(); ?>/api/get_staff_all_questions.php?paper_code=${encodeURIComponent(currentCourseCode)}`, { credentials: 'same-origin' });
    const data = await response.json();
    if (token !== allQuestionsRequestToken) return;
    if (!response.ok || !data.success) throw new Error(data.message || 'Unable to load COE-approved questions.');
    coeApprovedQuestions = Array.isArray(data.questions) ? data.questions : [];
    document.getElementById('allQuestionsCountBadge').textContent = currentQuestions.length + coeApprovedQuestions.length;
    renderAllQuestions();
  } catch (error) {
    if (container) container.innerHTML = `<div class="p-5 rounded-xl bg-rose-50 text-rose-700 text-sm">${escapeHtml(error.message)}</div>`;
  }
}
function renderAllQuestions() {
  const container = document.getElementById('allQuestionsList');
  const pager = document.getElementById('allQuestionsPagination');
  if (!container || !pager) return;
  const drafts = (Array.isArray(currentQuestions) ? currentQuestions : []).map(q => ({...q, _sourceStatus:'DRAFT'}));
  const approved = (Array.isArray(coeApprovedQuestions) ? coeApprovedQuestions : []).map(q => ({...q, _sourceStatus:'COE_APPROVED'}));
  let rows = [...drafts, ...approved];
  const status = document.getElementById('allQStatus')?.value || 'ALL';
  const section = document.getElementById('allQSection')?.value || 'ALL';
  const type = document.getElementById('allQType')?.value || 'ALL';
  const search = (document.getElementById('allQSearch')?.value || '').trim().toLowerCase();
  rows = rows.filter(q => {
    const qSection = String(q.section_type || q.section || '').toUpperCase();
    const qType = String(q.question_type || '').toUpperCase();
    if (status !== 'ALL' && q._sourceStatus !== status) return false;
    if (section !== 'ALL' && qSection !== section) return false;
    if (type !== 'ALL' && qType !== type) return false;
    if (search && !String(q.question_text || '').toLowerCase().includes(search) && !String(q.q_number || '').toLowerCase().includes(search)) return false;
    return true;
  });
  const total = rows.length;
  const pages = Math.max(1, Math.ceil(total / ALL_Q_PAGE_SIZE));
  allQPage = Math.min(Math.max(1, allQPage), pages);
  const start = (allQPage - 1) * ALL_Q_PAGE_SIZE;
  const pageRows = rows.slice(start, start + ALL_Q_PAGE_SIZE);
  if (!total) {
    container.innerHTML = '<div class="p-8 text-center text-sm text-slate-500 border border-dashed rounded-xl">No questions match the selected filters.</div>';
  } else {
    container.innerHTML = `<div class="overflow-x-auto border border-slate-200 rounded-xl"><table class="w-full text-sm"><thead class="bg-slate-50 text-slate-600"><tr><th class="p-3 text-left">Q.No</th><th class="p-3 text-left">Question</th><th class="p-3 text-center">Type</th><th class="p-3 text-center">Section</th><th class="p-3 text-center">Status</th></tr></thead><tbody>${pageRows.map((q,i)=>`<tr class="border-t border-slate-200 hover:bg-slate-50"><td class="p-3">${escapeHtml(q.q_number || start+i+1)}</td><td class="p-3 min-w-[280px]">${escapeHtml(q.question_text || '')}</td><td class="p-3 text-center">${escapeHtml(q.question_type || '—')}</td><td class="p-3 text-center">${escapeHtml(q.section_type || q.section || '—')}</td><td class="p-3 text-center"><span class="inline-flex px-2.5 py-1 rounded-full text-[11px] font-bold ${q._sourceStatus==='COE_APPROVED'?'bg-emerald-50 text-emerald-700':'bg-amber-50 text-amber-700'}">${q._sourceStatus==='COE_APPROVED'?'COE Approved':'Draft'}</span></td></tr>`).join('')}</tbody></table></div>`;
  }
  pager.innerHTML = `<div class="text-xs text-slate-500">Showing ${total ? start+1 : 0}–${Math.min(start+ALL_Q_PAGE_SIZE,total)} of ${total} questions</div><div class="flex items-center gap-2"><button type="button" ${allQPage<=1?'disabled':''} onclick="allQPage--;renderAllQuestions()" class="px-3 py-2 rounded-lg border text-xs font-semibold disabled:opacity-40">Previous</button><span class="text-xs font-semibold text-slate-600">Page ${allQPage} of ${pages}</span><button type="button" ${allQPage>=pages?'disabled':''} onclick="allQPage++;renderAllQuestions()" class="px-3 py-2 rounded-lg border text-xs font-semibold disabled:opacity-40">Next</button></div>`;
}

function parsePreviewArray(value) {
  if (Array.isArray(value)) return value;
  if (typeof value === 'string' && value.trim()) {
    try { const parsed = JSON.parse(value); return Array.isArray(parsed) ? parsed : []; } catch (e) { return []; }
  }
  return [];
}

function openQuestionImagePreview(questionId) {
  const q = (Array.isArray(currentQuestions) ? currentQuestions : []).find(item => String(item.id) === String(questionId));
  if (!q) return;
  const imageUrl = String(q.image_url || q.diagram_url || q.image_path || '').trim();
  const isMatch = String(q.question_type || '').toUpperCase() === 'MATCH';
  const modal = document.getElementById('questionImageModal');
  const content = document.getElementById('questionPreviewContent');
  const title = document.getElementById('questionImageTitle');
  if (!modal || !content) return;

  let html = `<div class="rounded-xl border border-slate-200 bg-white p-3"><div class="text-xs font-bold uppercase tracking-wide text-slate-500 mb-1">Question ${escapeHtml(q.q_number || '')}</div><div class="text-sm text-slate-800 whitespace-pre-wrap">${escapeHtml(q.question_text || '')}</div></div>`;
  if (isMatch) {
    const colA = parsePreviewArray(q.match_column_a);
    const colB = parsePreviewArray(q.match_column_b);
    const assignments = String(q.answer_key || '').split(',').map(v => v.trim());

    // Keep the two source columns side by side; show the matching sequence once below.
    const columnARows = colA.map((item, index) =>
      `<div class="match-preview-row match-preview-a"><span class="match-preview-number">${index + 1}.</span><span>${escapeHtml(item)}</span></div>`
    ).join('');
    const columnBRows = colB.map((item, index) =>
      `<div class="match-preview-row match-preview-b"><span class="match-preview-number">${index + 1}.</span><span>${escapeHtml(item)}</span></div>`
    ).join('');
    const answerPairs = colA.map((item, index) => {
      const optionNo = assignments[index] || '';
      return optionNo ? `${index + 1} → ${optionNo}` : `${index + 1} → —`;
    }).join(', ');

    html += `<section class="match-preview-wrap">
      <div class="font-bold text-slate-800 mb-2">Match the Following</div>
      <div class="match-preview-columns">
        <div class="match-preview-column">
          <div class="match-preview-heading">Column A</div>
          ${columnARows || '<div class="p-3 text-slate-400 text-sm">No Column A items saved.</div>'}
        </div>
        <div class="match-preview-column">
          <div class="match-preview-heading">Column B</div>
          ${columnBRows || '<div class="p-3 text-slate-400 text-sm">No Column B options saved.</div>'}
        </div>
      </div>
      <div class="match-preview-key"><strong>Answer Key:</strong> <span>${escapeHtml(answerPairs || '—')}</span></div>
    </section>`;
  }
  if (imageUrl) html += `<section class="rounded-xl border border-sky-200 bg-sky-50 p-3"><div class="text-sm font-bold text-sky-800 mb-2">Attached Image / Diagram</div><div class="flex justify-center"><img src="${escapeHtml(imageUrl)}" alt="Question attachment" class="max-w-full max-h-[55vh] object-contain rounded-lg bg-white shadow-sm" /></div></section>`;
  content.innerHTML = html;
  if (title) title.textContent = `Question ${q.q_number || ''} · Preview`;
  modal.classList.remove('hidden');
  modal.classList.add('flex');
  document.body.classList.add('overflow-hidden');
}

function closeQuestionImagePreview() {
  const modal = document.getElementById('questionImageModal');
  const content = document.getElementById('questionPreviewContent');
  if (modal) { modal.classList.add('hidden'); modal.classList.remove('flex'); }
  if (content) content.innerHTML = '';
  document.body.classList.remove('overflow-hidden');
}

</script>
<style>
.match-preview-columns{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
.match-preview-column{min-width:0;overflow:hidden;border:1px solid #e2e8f0;border-radius:10px;background:#fff}
.match-preview-heading{padding:9px 11px;background:#f8fafc;color:#263449;font-size:13px;font-weight:700}
.match-preview-row{display:flex;gap:8px;align-items:flex-start;padding:8px 11px;border-top:1px solid #e2e8f0;font-size:13px;line-height:1.45;overflow-wrap:anywhere}
.match-preview-number{flex:0 0 18px;color:#64748b}
.match-preview-a>span:last-child{color:#6554d9;font-weight:600}
.match-preview-b>span:last-child{color:#15966b;font-weight:600}
.match-preview-key{margin-top:10px;color:#334155;font-size:12px}
.match-preview-key span{color:#6554d9;font-weight:700}
@media(max-width:640px){.match-preview-columns{grid-template-columns:1fr}}
</style>


<script>
(function () {
  function init() {
    document.querySelectorAll('.qbank-tabs').forEach(function (bar) {
      var glider = document.createElement('span');
      glider.className = 'qbank-glider';
      glider.setAttribute('aria-hidden', 'true');
      bar.insertBefore(glider, bar.firstChild);

      function activeBtn() {
        return bar.querySelector(':scope > button.border-indigo-600');
      }
      var lastActive = activeBtn();

      function markUnder(btn) {
        bar.querySelectorAll(':scope > button.qbank-under').forEach(function (b) {
          if (b !== btn) b.classList.remove('qbank-under');
        });
        if (btn) btn.classList.add('qbank-under');
      }

      function moveTo(btn, instant) {
        markUnder(btn);
        if (!btn) { glider.style.opacity = 0; return; }
        if (instant) glider.classList.add('no-anim');
        glider.style.left   = btn.offsetLeft + 'px';
        glider.style.top    = btn.offsetTop + 'px';
        glider.style.width  = btn.offsetWidth + 'px';
        glider.style.height = btn.offsetHeight + 'px';
        glider.style.opacity = 1;
        if (instant) {
          void glider.offsetWidth;
          requestAnimationFrame(function () { glider.classList.remove('no-anim'); });
        }
      }
      function rest(instant) { moveTo(activeBtn(), instant); }

      function btnFrom(e) {
        var b = e.target.closest && e.target.closest('button');
        return b && b.parentNode === bar ? b : null;
      }

      bar.addEventListener('mouseover', function (e) { var b = btnFrom(e); if (b) moveTo(b); });
      bar.addEventListener('mouseleave', function () { rest(); });
      bar.addEventListener('focusin',  function (e) { var b = btnFrom(e); if (b) moveTo(b); });
      bar.addEventListener('focusout', function () { rest(); });

      // Follow active-tab changes from your tab-switching code
      new MutationObserver(function () {
        var a = activeBtn();
        if (a !== lastActive) { lastActive = a; rest(); }
      }).observe(bar, { subtree: true, attributes: true, attributeFilter: ['class'] });

      if (window.ResizeObserver) new ResizeObserver(function () { rest(true); }).observe(bar);
      window.addEventListener('load', function () { rest(true); });

      rest(true);
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
</script>


<?php require_once __DIR__ . '/../../includes/footer.php'; ?>